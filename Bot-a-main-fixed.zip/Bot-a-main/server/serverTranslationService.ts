import fs from 'fs';
import path from 'path';
import { executeMultiProviderCompletion, AIKeyConfig } from './multiProviderAI';
import { getPersistentDatabase, savePersistentDatabase } from './persistentStorage';

export interface ServerTranslationChapter {
  id: string;
  title: string;
  content: string;
  chapterNumber: number;
  sourceFileName?: string;
  isTranslated?: boolean;
}

export interface ServerTranslationJob {
  id: string;
  novelId: string;
  novelTitle: string;
  author?: string;
  genre?: string;
  synopsis?: string;
  coverGradient?: string;
  price: number;
  pricePerChapter?: number;
  isPriceLocked?: boolean;
  targetLang: 'fa' | 'ar' | 'en';
  engine: 'free' | 'ai';
  status: 'queued' | 'running' | 'paused' | 'completed' | 'cancelled' | 'error';
  totalChapters: number;
  completedChapters: number;
  currentChapterIndex: number;
  currentChapterTitle: string;
  currentProgressPercent: number;
  createdAt: number;
  updatedAt: number;
  error?: string;
  chapters: ServerTranslationChapter[];
}

const JOBS_FILE_PATH = path.join(process.cwd(), 'data', 'server_translation_jobs.json');

// In-memory cache of server jobs
const serverJobsMap: Map<string, ServerTranslationJob> = new Map();
const jobAbortControllers: Map<string, AbortController> = new Map();
let isWorkerRunning = false;

function loadJobsFromDisk() {
  try {
    if (fs.existsSync(JOBS_FILE_PATH)) {
      const raw = fs.readFileSync(JOBS_FILE_PATH, 'utf-8');
      const list: ServerTranslationJob[] = JSON.parse(raw);
      if (Array.isArray(list)) {
        list.forEach((job) => {
          serverJobsMap.set(job.id, job);
        });
      }
    }
  } catch (err) {
    console.warn('[ServerTranslation] Error loading jobs from disk:', err);
  }
}

function saveJobsToDisk() {
  try {
    const dataDir = path.join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    const list = Array.from(serverJobsMap.values());
    fs.writeFileSync(JOBS_FILE_PATH, JSON.stringify(list, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[ServerTranslation] Error saving jobs to disk:', err);
  }
}

// Helper: Free Web Translation Engine (Server-side)
export async function serverTranslateTextWithFreeEngine(
  text: string,
  targetLang: string = 'fa',
  sourceLang: string = 'auto'
): Promise<string> {
  const clean = text.trim();
  if (!clean) return '';

  const paragraphs = clean.split(/\n\s*\n/);
  const chunks: string[] = [];
  let cur = '';

  for (const p of paragraphs) {
    if ((cur + '\n\n' + p).length > 2800 && cur.length > 0) {
      chunks.push(cur.trim());
      cur = p;
    } else {
      cur = cur ? cur + '\n\n' + p : p;
    }
  }
  if (cur) chunks.push(cur.trim());

  const translateChunk = async (chunk: string): Promise<string> => {
    if (!chunk.trim()) return '';

    // 1. Google Translate gtx
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLang}&tl=${targetLang}&dt=t&q=${encodeURIComponent(chunk)}`;
      const res = await fetch(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        },
        signal: AbortSignal.timeout(9000),
      });

      if (res.ok) {
        const rawJson = (await res.json()) as any;
        if (Array.isArray(rawJson) && Array.isArray(rawJson[0])) {
          const trans = rawJson[0]
            .map((item: any) => (Array.isArray(item) ? item[0] : ''))
            .filter(Boolean)
            .join('');
          if (trans && trans.trim().length > 0) {
            return trans.trim();
          }
        }
      }
    } catch {}

    // 2. Fallback: MyMemory
    try {
      const myMemoryUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(chunk.substring(0, 500))}&langpair=${sourceLang === 'auto' ? 'en' : sourceLang}|${targetLang}`;
      const res = await fetch(myMemoryUrl, { signal: AbortSignal.timeout(6000) });
      if (res.ok) {
        const data = (await res.json()) as any;
        if (data.responseData?.translatedText && !data.responseData.translatedText.includes('MYMEMORY WARNING')) {
          return data.responseData.translatedText.trim();
        }
      }
    } catch {}

    return chunk;
  };

  const results = await Promise.all(chunks.map((c) => translateChunk(c)));
  return results.join('\n\n');
}

// Helper: AI Novel Translation (Server-side)
export async function serverTranslateNovelWithAI(
  text: string,
  title: string = '',
  targetLang: string = 'fa',
  aiKeys?: AIKeyConfig[]
): Promise<{ title: string; content: string; engineUsed: string }> {
  const isFa = targetLang === 'fa';
  const isAr = targetLang === 'ar';
  const langName = isFa ? 'Persian (Farsi - فارسی سلیس، روان و ادبی)' : isAr ? 'Arabic (العربية الفصحى)' : 'English';

  const cleanText = text.trim();
  if (!cleanText) {
    return { title: title.trim(), content: '', engineUsed: 'none' };
  }

  const activeKeys = [...(aiKeys && aiKeys.length > 0 ? aiKeys : [])];
  if (activeKeys.length === 0 && process.env.GEMINI_API_KEY) {
    activeKeys.push({
      key: process.env.GEMINI_API_KEY,
      provider: 'gemini',
      selectedModel: 'gemini-2.5-flash',
      availableModels: ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-2.0-flash-lite', 'gemini-3.7-flash', 'gemini-flash-latest', 'gemini-2.5-pro'],
      isValid: true,
    });
  }

  // If no AI keys available, fallback to free web engine
  if (activeKeys.length === 0) {
    const [transTitle, transContent] = await Promise.all([
      title && title.trim() ? serverTranslateTextWithFreeEngine(title, targetLang) : Promise.resolve(title),
      serverTranslateTextWithFreeEngine(cleanText, targetLang),
    ]);
    return {
      title: transTitle || title,
      content: transContent || cleanText,
      engineUsed: 'free_engine',
    };
  }

  const CHUNK_SIZE = 8500;
  const chunks: string[] = [];

  if (cleanText.length <= CHUNK_SIZE) {
    chunks.push(cleanText);
  } else {
    const paragraphs = cleanText.split(/\n\s*\n/);
    let currentChunk = '';
    for (const p of paragraphs) {
      if ((currentChunk + '\n\n' + p).length > CHUNK_SIZE && currentChunk.length > 0) {
        chunks.push(currentChunk.trim());
        currentChunk = p;
      } else {
        currentChunk = currentChunk ? currentChunk + '\n\n' + p : p;
      }
    }
    if (currentChunk) {
      chunks.push(currentChunk.trim());
    }
  }

  const translateTitleTask = async (): Promise<string> => {
    if (!title || !title.trim()) return title;
    try {
      const titlePrompt = `Translate this web novel chapter title into ${langName}. Return ONLY the translated title text without quotes:\n\n${title}`;
      const titleResp = await executeMultiProviderCompletion({
        keys: activeKeys,
        prompt: titlePrompt,
        temperature: 0.2,
      });
      if (titleResp.text) {
        return titleResp.text.replace(/^["'«]+|["'»]+$/g, '').trim();
      }
    } catch {
      try {
        return await serverTranslateTextWithFreeEngine(title, targetLang);
      } catch {}
    }
    return title;
  };

  const translateSingleAIChunk = async (chunk: string): Promise<string> => {
    const prompt = `You are a professional literary novel translator specializing in web novels and light novels.
Translate the following story excerpt into ${langName}.

Requirements:
1. Deliver a natural, fluent, and immersive literary translation.
2. Translate all dialogue with natural tone and emotional depth.
3. Preserve paragraph breaks (double newlines).
4. Do NOT omit or summarize any sentences.
5. Return ONLY the translated story text.

Novel Text to Translate:
${chunk}`;

    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const chunkRes = await executeMultiProviderCompletion({
          keys: activeKeys,
          prompt,
          temperature: 0.3,
        });
        if (chunkRes.text && chunkRes.text.trim().length > 10) {
          return chunkRes.text.trim();
        }
      } catch {
        if (attempt === 1) {
          await new Promise((r) => setTimeout(r, 400));
        }
      }
    }

    try {
      const freeRes = await serverTranslateTextWithFreeEngine(chunk, targetLang);
      if (freeRes && freeRes.trim().length > 5) {
        return freeRes.trim();
      }
    } catch {}

    return chunk;
  };

  const [translatedTitle, ...translatedChunks] = await Promise.all([
    translateTitleTask(),
    ...chunks.map((c) => translateSingleAIChunk(c)),
  ]);

  return {
    title: translatedTitle || title,
    content: translatedChunks.join('\n\n'),
    engineUsed: 'ai_with_failover',
  };
}

/**
 * Live sync translated chapters into Persistent Database customNovels collection
 */
function syncServerJobToDatabase(job: ServerTranslationJob) {
  try {
    const db = getPersistentDatabase();
    if (!Array.isArray(db.customNovels)) {
      db.customNovels = [];
    }

    const existingIdx = db.customNovels.findIndex((n: any) => n.id === job.novelId);
    const formattedChapters = job.chapters.map((c) => ({
      id: c.id,
      title: c.title,
      content: c.content,
      chapterNumber: c.chapterNumber,
      price: job.pricePerChapter || 2,
    }));

    const novelRecord = {
      id: job.novelId,
      title: job.novelTitle,
      author: job.author || 'ناشناس',
      genre: job.genre || 'عمومی',
      synopsis: job.synopsis || '',
      coverColor: job.coverGradient || 'from-blue-600 via-indigo-700 to-purple-900',
      price: job.price,
      pricePerChapter: job.pricePerChapter || 2,
      isPriceLocked: job.isPriceLocked ?? true,
      chapters: formattedChapters,
      isDefault: false,
      rating: 5.0,
      uploadedAt: new Date(job.createdAt).toISOString(),
      lastTranslatedAt: new Date().toISOString(),
    };

    if (existingIdx >= 0) {
      db.customNovels[existingIdx] = {
        ...db.customNovels[existingIdx],
        ...novelRecord,
      };
    } else {
      db.customNovels.unshift(novelRecord);
    }

    db.lastUpdated = Date.now();
    savePersistentDatabase();
  } catch (err) {
    console.warn('[ServerTranslation] Error syncing novel to persistent DB:', err);
  }
}

/**
 * Background worker loop for processing running jobs on the server
 */
async function processServerJob(jobId: string) {
  const job = serverJobsMap.get(jobId);
  if (!job || (job.status !== 'running' && job.status !== 'queued')) return;

  job.status = 'running';
  job.updatedAt = Date.now();
  saveJobsToDisk();

  const abortCtrl = new AbortController();
  jobAbortControllers.set(jobId, abortCtrl);

  const concurrency = job.engine === 'free' ? 3 : 2;
  const chapters = job.chapters;
  let nextIdx = 0;

  // Find first uncompleted chapter
  for (let i = 0; i < chapters.length; i++) {
    if (!chapters[i].isTranslated) {
      nextIdx = i;
      break;
    }
  }

  const worker = async () => {
    while (nextIdx < chapters.length) {
      const curJob = serverJobsMap.get(jobId);
      if (!curJob || curJob.status !== 'running' || abortCtrl.signal.aborted) {
        break;
      }

      const idx = nextIdx++;
      const ch = chapters[idx];
      if (!ch) continue;
      if (ch.isTranslated) continue;

      curJob.currentChapterIndex = idx;
      curJob.currentChapterTitle = ch.title;
      curJob.updatedAt = Date.now();
      curJob.currentProgressPercent = Math.min(
        100,
        Math.round((curJob.completedChapters / curJob.totalChapters) * 100)
      );
      saveJobsToDisk();

      try {
        if (curJob.engine === 'free') {
          const [transTitle, transContent] = await Promise.all([
            ch.title ? serverTranslateTextWithFreeEngine(ch.title, curJob.targetLang) : Promise.resolve(ch.title),
            serverTranslateTextWithFreeEngine(ch.content, curJob.targetLang),
          ]);
          if (transContent && transContent.trim().length > 10) {
            ch.content = transContent;
            if (transTitle) ch.title = transTitle;
            ch.isTranslated = true;
          }
        } else {
          const aiRes = await serverTranslateNovelWithAI(ch.content, ch.title, curJob.targetLang);
          if (aiRes.content && aiRes.content.trim().length > 10) {
            ch.content = aiRes.content;
            if (aiRes.title) ch.title = aiRes.title;
            ch.isTranslated = true;
          }
        }

        curJob.completedChapters = chapters.filter((c) => c.isTranslated).length;
        curJob.currentProgressPercent = Math.min(
          100,
          Math.round((curJob.completedChapters / curJob.totalChapters) * 100)
        );
        curJob.updatedAt = Date.now();

        // Progressive save directly to persistent database!
        syncServerJobToDatabase(curJob);
        saveJobsToDisk();
      } catch (err: any) {
        console.warn(`[ServerTranslation] Error translating chapter ${idx + 1}:`, err?.message || err);
      }
    }
  };

  try {
    const workers = Array.from({ length: Math.min(concurrency, chapters.length) }, () => worker());
    await Promise.all(workers);

    const finalJob = serverJobsMap.get(jobId);
    if (finalJob && finalJob.status === 'running') {
      const allDone = finalJob.chapters.every((c) => c.isTranslated);
      if (allDone) {
        finalJob.status = 'completed';
        finalJob.completedChapters = finalJob.totalChapters;
        finalJob.currentProgressPercent = 100;
        finalJob.updatedAt = Date.now();
        syncServerJobToDatabase(finalJob);
        saveJobsToDisk();
        console.info(`[ServerTranslation] Job ${jobId} («${finalJob.novelTitle}») successfully COMPLETED on server!`);
      }
    }
  } catch (err: any) {
    const j = serverJobsMap.get(jobId);
    if (j) {
      j.status = 'error';
      j.error = err?.message || 'خطا در پردازش ترجمه در سرور';
      j.updatedAt = Date.now();
      saveJobsToDisk();
    }
  } finally {
    jobAbortControllers.delete(jobId);
  }
}

/**
 * Public API methods
 */

export function createOrEnqueueServerJob(params: {
  novelId?: string;
  novelTitle: string;
  author?: string;
  genre?: string;
  synopsis?: string;
  coverGradient?: string;
  price?: number;
  pricePerChapter?: number;
  isPriceLocked?: boolean;
  targetLang?: 'fa' | 'ar' | 'en';
  engine?: 'free' | 'ai';
  chapters: Array<{
    id?: string;
    title: string;
    content: string;
    chapterNumber?: number;
    sourceFileName?: string;
    isTranslated?: boolean;
  }>;
}): ServerTranslationJob {
  loadJobsFromDisk();

  const novelId = params.novelId || `novel-srv-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
  const jobId = `srv-job-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

  const normalizedChapters: ServerTranslationChapter[] = params.chapters.map((ch, idx) => ({
    id: ch.id || `ch-${novelId}-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`,
    title: ch.title || `فصل ${idx + 1}`,
    content: ch.content,
    chapterNumber: ch.chapterNumber || idx + 1,
    sourceFileName: ch.sourceFileName,
    isTranslated: Boolean(ch.isTranslated),
  }));

  const initialCompleted = normalizedChapters.filter((c) => c.isTranslated).length;

  const job: ServerTranslationJob = {
    id: jobId,
    novelId,
    novelTitle: params.novelTitle,
    author: params.author || 'نویسنده',
    genre: params.genre || 'عمومی',
    synopsis: params.synopsis || 'رمان در حال ترجمه در سرور...',
    coverGradient: params.coverGradient || 'from-blue-600 via-indigo-700 to-purple-900',
    price: params.price ?? 2,
    pricePerChapter: params.pricePerChapter ?? 2,
    isPriceLocked: params.isPriceLocked ?? true,
    targetLang: params.targetLang || 'fa',
    engine: params.engine || 'free',
    status: 'running',
    totalChapters: normalizedChapters.length,
    completedChapters: initialCompleted,
    currentChapterIndex: 0,
    currentChapterTitle: normalizedChapters[0]?.title || '',
    currentProgressPercent: normalizedChapters.length > 0
      ? Math.round((initialCompleted / normalizedChapters.length) * 100)
      : 0,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    chapters: normalizedChapters,
  };

  serverJobsMap.set(jobId, job);
  saveJobsToDisk();

  // Instantly sync novel placeholder into persistent database
  syncServerJobToDatabase(job);

  // Trigger non-blocking worker execution on server
  setTimeout(() => {
    processServerJob(jobId).catch((err) =>
      console.error('[ServerTranslation] Uncaught job error:', err)
    );
  }, 100);

  return job;
}

export function getAllServerJobs(): ServerTranslationJob[] {
  loadJobsFromDisk();
  return Array.from(serverJobsMap.values()).sort((a, b) => b.createdAt - a.createdAt);
}

export function getServerJobById(jobId: string): ServerTranslationJob | undefined {
  loadJobsFromDisk();
  return serverJobsMap.get(jobId);
}

export function pauseServerJob(jobId: string): boolean {
  loadJobsFromDisk();
  const job = serverJobsMap.get(jobId);
  if (!job) return false;

  job.status = 'paused';
  job.updatedAt = Date.now();
  const ctrl = jobAbortControllers.get(jobId);
  if (ctrl) {
    ctrl.abort();
    jobAbortControllers.delete(jobId);
  }
  saveJobsToDisk();
  return true;
}

export function resumeServerJob(jobId: string): boolean {
  loadJobsFromDisk();
  const job = serverJobsMap.get(jobId);
  if (!job) return false;

  job.status = 'running';
  job.error = undefined;
  job.updatedAt = Date.now();
  saveJobsToDisk();

  setTimeout(() => {
    processServerJob(jobId).catch((err) =>
      console.error('[ServerTranslation] Uncaught resume error:', err)
    );
  }, 100);

  return true;
}

export function cancelServerJob(jobId: string): boolean {
  loadJobsFromDisk();
  const job = serverJobsMap.get(jobId);
  if (!job) return false;

  job.status = 'cancelled';
  job.updatedAt = Date.now();
  const ctrl = jobAbortControllers.get(jobId);
  if (ctrl) {
    ctrl.abort();
    jobAbortControllers.delete(jobId);
  }
  saveJobsToDisk();
  return true;
}

export function deleteServerJob(jobId: string): boolean {
  loadJobsFromDisk();
  cancelServerJob(jobId);
  const deleted = serverJobsMap.delete(jobId);
  saveJobsToDisk();
  return deleted;
}

// Auto-initialize jobs on module load & resume any uncompleted jobs
loadJobsFromDisk();
const existingJobs = Array.from(serverJobsMap.values());
existingJobs.forEach((j) => {
  if (j.status === 'running') {
    // Resume jobs that were running before server restarted
    setTimeout(() => {
      processServerJob(j.id).catch(() => {});
    }, 1500);
  }
});
