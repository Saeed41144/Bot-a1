import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  Plus,
  Minus,
  Sparkles,
  Volume2,
  VolumeX,
  Clock,
  Coffee,
  Sun,
  Timer,
  CheckCircle2,
  Target,
  ListTodo,
  Flame,
  Award,
  History,
  TrendingUp,
  Sliders,
  Check,
  ChevronDown,
  Trash2,
  Minimize2,
  Music,
  Search,
} from 'lucide-react';
import {
  Language,
  Habit,
  Task,
  PomodoroMode,
  PomodoroTargetType,
  PomodoroAmbientSound,
  PomodoroCustomSound,
  AdvancedSettings,
  ThemeMode,
  TelegramConfig,
} from '../types';
import { translations, formatNumber } from '../utils/translations';
import {
  playPomodoroBellSound,
  playBreakCompleteSound,
  playTickSound,
  startAmbientSound,
  stopAmbientSound,
  triggerCelebrationConfetti,
  triggerHapticFeedback,
} from '../utils/feedbackEffects';
import { getAllCustomPomodoroSounds } from '../utils/pomodoroSoundManager';
import {
  getPomodoroSessions,
  addPomodoroSession,
  clearPomodoroSessions,
  deletePomodoroSession,
  calculatePomodoroStats,
  formatPomodoroDuration,
} from '../utils/pomodoroStorage';
import { getTodayString } from '../utils/persianDate';

export interface PomodoroModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  theme?: ThemeMode;
  habits: Habit[];
  tasks: Task[];

  // Timer State & Handlers
  mode?: PomodoroMode | string;
  setMode?: (m: PomodoroMode) => void;
  onModeChange?: (m: 'focus' | 'shortBreak' | 'longBreak' | 'short_break' | 'long_break' | 'stopwatch') => void;

  timeLeft?: number;
  setTimeLeft?: React.Dispatch<React.SetStateAction<number>>;
  totalDuration?: number;
  setTotalDuration?: React.Dispatch<React.SetStateAction<number>>;

  isRunning?: boolean;
  setIsRunning?: React.Dispatch<React.SetStateAction<boolean>>;
  onToggleRunning?: () => void;
  onReset?: () => void;

  // Target
  activeTargetType?: PomodoroTargetType;
  initialTargetType?: PomodoroTargetType;
  setActiveTargetType?: (type: PomodoroTargetType) => void;

  activeTargetId?: string | null;
  initialTargetId?: string | null;
  setActiveTargetId?: (id: string | undefined | null) => void;
  onTargetChange?: (type: PomodoroTargetType, id: string | null) => void;

  // Ambient Sound
  ambientSound?: PomodoroAmbientSound | string;
  setAmbientSound?: (s: PomodoroAmbientSound) => void;
  onAmbientSoundChange?: (s: any) => void;
  soundVolume?: number;
  onVolumeChange?: (volume: number) => void;

  // Completed Sessions count
  completedSessions?: number;
  completedSessionsCount?: number;
  setCompletedSessionsCount?: React.Dispatch<React.SetStateAction<number>>;

  // Settings & Callbacks
  pomodoroConfig?: any;
  advancedSettings?: AdvancedSettings;
  telegramConfig?: TelegramConfig;
  onUpdateSettings?: (settings: Partial<AdvancedSettings>) => void;
  onOpenSettings?: () => void;

  // Action Callbacks
  onUpdateHabitFocus?: (habitId: string, minutes: number, markDoneToday?: boolean) => void;
  onUpdateTaskFocus?: (taskId: string, minutes: number, markCompleted?: boolean) => void;
  onCompleteHabit?: (habitId: string) => void;
  onCompleteTask?: (taskId: string) => void;
  onAddGeneralFocus?: (minutes: number) => void;
  onRewardCoins?: (coins: number, reason: string) => void;
}

export const PomodoroModal: React.FC<PomodoroModalProps> = ({
  isOpen,
  onClose,
  language,
  theme,
  habits = [],
  tasks = [],
  mode = 'focus',
  setMode,
  onModeChange,
  timeLeft = 25 * 60,
  setTimeLeft,
  totalDuration = 25 * 60,
  setTotalDuration,
  isRunning = false,
  setIsRunning,
  onToggleRunning,
  onReset,
  activeTargetType,
  initialTargetType = 'none',
  setActiveTargetType,
  activeTargetId,
  initialTargetId = null,
  setActiveTargetId,
  onTargetChange,
  ambientSound = 'none',
  setAmbientSound,
  onAmbientSoundChange,
  soundVolume = 0.35,
  onVolumeChange,
  completedSessions,
  completedSessionsCount,
  setCompletedSessionsCount,
  pomodoroConfig,
  advancedSettings,
  telegramConfig,
  onUpdateSettings,
  onOpenSettings,
  onUpdateHabitFocus,
  onUpdateTaskFocus,
  onCompleteHabit,
  onCompleteTask,
  onAddGeneralFocus,
  onRewardCoins,
}) => {
  const t = translations[language] || translations.fa;
  const isRtl = t.dir === 'rtl';

  // Normalize mode
  const normalizedMode: PomodoroMode =
    mode === 'shortBreak'
      ? 'short_break'
      : mode === 'longBreak'
      ? 'long_break'
      : mode === 'short_break' || mode === 'long_break' || mode === 'stopwatch'
      ? (mode as PomodoroMode)
      : 'focus';

  // Internal target state fallback if uncontrolled
  const [internalTargetType, setInternalTargetType] = useState<PomodoroTargetType>(
    activeTargetType || initialTargetType || 'none'
  );
  const [internalTargetId, setInternalTargetId] = useState<string | null>(
    activeTargetId ?? initialTargetId ?? null
  );

  // Sync internal state when external props change
  useEffect(() => {
    if (activeTargetType !== undefined) {
      setInternalTargetType(activeTargetType);
    } else if (initialTargetType !== undefined) {
      setInternalTargetType(initialTargetType);
    }
  }, [activeTargetType, initialTargetType]);

  useEffect(() => {
    if (activeTargetId !== undefined) {
      setInternalTargetId(activeTargetId);
    } else if (initialTargetId !== undefined) {
      setInternalTargetId(initialTargetId);
    }
  }, [activeTargetId, initialTargetId]);

  const effectiveTargetType: PomodoroTargetType =
    activeTargetType !== undefined ? activeTargetType : internalTargetType;
  const effectiveTargetId: string | null =
    activeTargetId !== undefined ? activeTargetId : internalTargetId;

  const effectiveCompletedSessions =
    completedSessions !== undefined
      ? completedSessions
      : completedSessionsCount !== undefined
      ? completedSessionsCount
      : 0;

  const [activeTab, setActiveTab] = useState<'timer' | 'history'>('timer');
  const [manualSuccessMsg, setManualSuccessMsg] = useState<string>('');
  const [targetDropdownOpen, setTargetDropdownOpen] = useState<boolean>(false);
  const [targetSearchQuery, setTargetSearchQuery] = useState<string>('');
  const [targetFilterTab, setTargetFilterTab] = useState<'all' | 'habit' | 'task'>('all');
  const [historyRefreshKey, setHistoryRefreshKey] = useState<number>(0);
  const [customSounds, setCustomSounds] = useState<PomodoroCustomSound[]>([]);
  const sessionStartTimestampRef = useRef<number | null>(null);

  // Track session start time when timer starts
  useEffect(() => {
    if (isRunning && !sessionStartTimestampRef.current) {
      sessionStartTimestampRef.current = Date.now();
    } else if (!isRunning && timeLeft === (totalDuration || 25 * 60)) {
      sessionStartTimestampRef.current = null;
    }
  }, [isRunning, timeLeft, totalDuration]);

  // Load custom sounds from IndexedDB/Storage
  useEffect(() => {
    let isMounted = true;
    const loadSounds = async () => {
      try {
        const sounds = await getAllCustomPomodoroSounds();
        if (isMounted) {
          setCustomSounds(sounds);
        }
      } catch (err) {
        console.warn('Failed to load custom pomodoro sounds:', err);
      }
    };

    if (isOpen) {
      loadSounds();
    }

    const handleSoundsChanged = () => {
      loadSounds();
    };

    window.addEventListener('pomodoroCustomSoundsChanged', handleSoundsChanged);
    return () => {
      isMounted = false;
      window.removeEventListener('pomodoroCustomSoundsChanged', handleSoundsChanged);
    };
  }, [isOpen]);

  // Completion Dialog State
  const [showCompletionModal, setShowCompletionModal] = useState<boolean>(false);
  const [lastFinishedSession, setLastFinishedSession] = useState<{
    minutes: number;
    mode: PomodoroMode;
    coins: number;
    xp: number;
    targetName: string;
    targetType: PomodoroTargetType;
    targetId?: string | null;
  } | null>(null);

  // Load history sessions
  const sessions = useMemo(() => {
    return getPomodoroSessions();
  }, [historyRefreshKey, isOpen]);

  const stats = useMemo(() => {
    return calculatePomodoroStats(sessions, getTodayString(), habits, tasks);
  }, [sessions, habits, tasks]);

  // Current attached target
  const currentHabit = useMemo(() => {
    if (effectiveTargetType === 'habit' && effectiveTargetId) {
      return habits.find((h) => h.id === effectiveTargetId);
    }
    return null;
  }, [habits, effectiveTargetType, effectiveTargetId]);

  const currentTask = useMemo(() => {
    if (effectiveTargetType === 'task' && effectiveTargetId) {
      return tasks.find((t) => t.id === effectiveTargetId);
    }
    return null;
  }, [tasks, effectiveTargetType, effectiveTargetId]);

  const activeTargetName = currentHabit
    ? currentHabit.name
    : currentTask
    ? currentTask.title
    : t.pomodoroNoTarget || 'تمرکز آزاد';

  const activeTargetColor = currentHabit?.color || (currentTask ? currentTask.color || '#10b981' : '#6366f1');

  // Handle target change safely
  const handleSelectTarget = (type: PomodoroTargetType, id: string | null = null) => {
    setInternalTargetType(type);
    setInternalTargetId(id);

    if (typeof onTargetChange === 'function') {
      onTargetChange(type, id);
    }
    if (typeof setActiveTargetType === 'function') {
      setActiveTargetType(type);
    }
    if (typeof setActiveTargetId === 'function') {
      setActiveTargetId(id || undefined);
    }
    setTargetDropdownOpen(false);
  };

  // Switch Mode safely
  const handleSwitchMode = (newMode: PomodoroMode) => {
    if (typeof onModeChange === 'function') {
      const modeArg =
        newMode === 'short_break' ? 'shortBreak' : newMode === 'long_break' ? 'longBreak' : newMode;
      onModeChange(modeArg as any);
    }
    if (typeof setMode === 'function') {
      setMode(newMode);
    }

    const defaultDurationMins =
      newMode === 'short_break'
        ? advancedSettings?.pomodoroShortBreakDuration || pomodoroConfig?.shortBreakMinutes || 5
        : newMode === 'long_break'
        ? advancedSettings?.pomodoroLongBreakDuration || pomodoroConfig?.longBreakMinutes || 15
        : newMode === 'stopwatch'
        ? 0
        : advancedSettings?.pomodoroFocusDuration || pomodoroConfig?.focusMinutes || 25;

    const newDurSeconds = defaultDurationMins * 60;

    if (typeof setTotalDuration === 'function') {
      setTotalDuration(newDurSeconds);
    }
    if (typeof setTimeLeft === 'function') {
      setTimeLeft(newDurSeconds);
    }
  };

  const handleTogglePlay = () => {
    if (typeof onToggleRunning === 'function') {
      onToggleRunning();
    } else if (typeof setIsRunning === 'function') {
      setIsRunning(!isRunning);
    }
    triggerHapticFeedback(25);
  };

  const handleResetClick = () => {
    if (typeof onReset === 'function') {
      onReset();
    } else {
      const defaultDurationMins =
        normalizedMode === 'short_break'
          ? advancedSettings?.pomodoroShortBreakDuration || pomodoroConfig?.shortBreakMinutes || 5
          : normalizedMode === 'long_break'
          ? advancedSettings?.pomodoroLongBreakDuration || pomodoroConfig?.longBreakMinutes || 15
          : normalizedMode === 'stopwatch'
          ? 0
          : advancedSettings?.pomodoroFocusDuration || pomodoroConfig?.focusMinutes || 25;
      const newDurSeconds = defaultDurationMins * 60;
      if (typeof setTimeLeft === 'function') setTimeLeft(newDurSeconds);
      if (typeof setTotalDuration === 'function') setTotalDuration(newDurSeconds);
      if (typeof setIsRunning === 'function') setIsRunning(false);
    }
  };

  const handleAdjustTime = (deltaMinutes: number) => {
    if (normalizedMode === 'stopwatch') return;
    const deltaSeconds = deltaMinutes * 60;
    if (typeof setTimeLeft === 'function') {
      setTimeLeft((prev) => Math.max(60, prev + deltaSeconds));
    }
    if (typeof setTotalDuration === 'function') {
      setTotalDuration((prev) => Math.max(60, prev + deltaSeconds));
    }
  };

  const handleSetPreset = (minutes: number) => {
    if (normalizedMode === 'stopwatch') return;
    const sec = minutes * 60;
    if (typeof setTotalDuration === 'function') {
      setTotalDuration(sec);
    }
    if (typeof setTimeLeft === 'function') {
      setTimeLeft(sec);
    }
  };

  // Finish session safely
  const handleSessionFinished = () => {
    if (typeof setIsRunning === 'function') {
      setIsRunning(false);
    }

    const safeTotal = totalDuration || 25 * 60;
    const elapsedSeconds =
      normalizedMode === 'stopwatch'
        ? timeLeft
        : Math.max(0, safeTotal - timeLeft);

    // Calculate actual elapsed minutes and seconds accurately based on real time spent
    const elapsedMinutes = Math.floor(elapsedSeconds / 60);
    const recordedMinutes = elapsedSeconds >= 30 ? Math.max(1, elapsedMinutes) : elapsedMinutes;

    // Strict 25-Minute Reward Rule:
    // Only grant coins & XP if user has actually completed at least 25 minutes of focus,
    // or if the countdown timer of 25+ minutes completed down to zero.
    const isCompleted25Min = recordedMinutes >= 25 || (safeTotal >= 25 * 60 && timeLeft <= 0);

    const configuredCoins = advancedSettings?.pomodoroRewardCoins ?? pomodoroConfig?.rewardCoins ?? 5;
    const configuredXp = advancedSettings?.pomodoroRewardXp ?? pomodoroConfig?.rewardXp ?? 20;

    let coins = 0;
    let xp = 0;

    if (normalizedMode === 'focus' || normalizedMode === 'stopwatch') {
      if (isCompleted25Min) {
        playPomodoroBellSound();
        triggerHapticFeedback([50, 100, 50, 100]);
        triggerCelebrationConfetti();
        const intervals = Math.max(1, Math.floor(recordedMinutes / 25));
        coins = intervals * configuredCoins;
        xp = intervals * configuredXp;
      } else {
        triggerHapticFeedback(30);
      }

      // Always save session even if partial or short (< 25 min), recording exact seconds
      if (elapsedSeconds > 0 || recordedMinutes > 0) {
        const now = new Date();
        const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
        
        const startTs = sessionStartTimestampRef.current || (now.getTime() - elapsedSeconds * 1000);
        const startDate = new Date(startTs);
        const startTimeStr = `${String(startDate.getHours()).padStart(2, '0')}:${String(startDate.getMinutes()).padStart(2, '0')}`;

        addPomodoroSession({
          targetType: effectiveTargetType,
          targetId: effectiveTargetId || undefined,
          targetName: activeTargetName,
          targetTitle: activeTargetName,
          durationMinutes: recordedMinutes,
          durationSeconds: elapsedSeconds,
          plannedMinutes: Math.round(safeTotal / 60),
          isCompletedFull: isCompleted25Min,
          completedAt: getTodayString(),
          time: timeStr,
          startTime: startTimeStr,
          endTime: timeStr,
          startTimestamp: startTs,
          targetColor: activeTargetColor,
          targetCategory: effectiveTargetType,
          mode: normalizedMode,
          rewardCoinsEarned: coins,
          rewardXpEarned: xp,
        });

        sessionStartTimestampRef.current = null;

        if (effectiveTargetType === 'habit' && effectiveTargetId && onUpdateHabitFocus) {
          onUpdateHabitFocus(effectiveTargetId, recordedMinutes, false);
        } else if (effectiveTargetType === 'task' && effectiveTargetId && onUpdateTaskFocus) {
          onUpdateTaskFocus(effectiveTargetId, recordedMinutes, false);
        } else if (onAddGeneralFocus) {
          onAddGeneralFocus(recordedMinutes);
        }
      }

      if (onRewardCoins && coins > 0) {
        onRewardCoins(coins, `${t.pomodoroFocusMode} (${recordedMinutes} ${t.pomodoroMinutesLabel})`);
      }

      // Send Instant Push Notification to Telegram if configured
      if (
        telegramConfig &&
        telegramConfig.notifyOnPomodoroCompletion !== false &&
        telegramConfig.botToken &&
        telegramConfig.chatId
      ) {
        fetch('/api/telegram/notify-event', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            botToken: telegramConfig.botToken,
            chatId: telegramConfig.chatId,
            eventType: 'pomodoro_completed',
            title: activeTargetName || (language === 'fa' ? 'جلسه تمرکز عمیق' : 'Deep Focus Session'),
            durationMinutes: recordedMinutes,
            earnedCoins: coins,
            language,
          }),
        }).catch(() => {});
      }

      if (typeof setCompletedSessionsCount === 'function' && isCompleted25Min) {
        setCompletedSessionsCount((prev) => prev + 1);
      }
      setHistoryRefreshKey((prev) => prev + 1);

      setLastFinishedSession({
        minutes: recordedMinutes,
        seconds: elapsedSeconds,
        mode: normalizedMode,
        coins,
        xp,
        targetName: activeTargetName,
        targetType: effectiveTargetType,
        targetId: effectiveTargetId,
        isCompletedFull: isCompleted25Min,
      });

      setShowCompletionModal(true);

      // RESET TIMER so next session starts fresh from the beginning
      if (normalizedMode === 'stopwatch') {
        if (typeof setTimeLeft === 'function') setTimeLeft(0);
        if (typeof setTotalDuration === 'function') setTotalDuration(0);
      } else {
        const freshDuration = (advancedSettings?.pomodoroFocusDuration || pomodoroConfig?.focusMinutes || 25) * 60;
        if (typeof setTimeLeft === 'function') setTimeLeft(freshDuration);
        if (typeof setTotalDuration === 'function') setTotalDuration(freshDuration);
      }
    } else {
      playBreakCompleteSound();
      handleSwitchMode('focus');
    }
  };

  // Manual log
  const handleManualLog = (mins: number) => {
    if (mins <= 0) return;
    const isCompleted25Min = mins >= 25;
    const configuredCoins = advancedSettings?.pomodoroRewardCoins ?? pomodoroConfig?.rewardCoins ?? 5;
    const configuredXp = advancedSettings?.pomodoroRewardXp ?? pomodoroConfig?.rewardXp ?? 20;

    const intervals = isCompleted25Min ? Math.floor(mins / 25) : 0;
    const coins = intervals * configuredCoins;
    const xp = intervals * configuredXp;

    const now = new Date();
    const endStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const startD = new Date(now.getTime() - mins * 60 * 1000);
    const startStr = `${String(startD.getHours()).padStart(2, '0')}:${String(startD.getMinutes()).padStart(2, '0')}`;

    addPomodoroSession({
      targetType: effectiveTargetType,
      targetId: effectiveTargetId || undefined,
      targetName: activeTargetName,
      targetTitle: activeTargetName,
      durationMinutes: mins,
      durationSeconds: mins * 60,
      plannedMinutes: mins,
      isCompletedFull: isCompleted25Min,
      completedAt: getTodayString(),
      time: endStr,
      startTime: startStr,
      endTime: endStr,
      startTimestamp: startD.getTime(),
      targetColor: activeTargetColor,
      targetCategory: effectiveTargetType,
      mode: 'focus',
      rewardCoinsEarned: coins,
      rewardXpEarned: xp,
    });

    if (effectiveTargetType === 'habit' && effectiveTargetId && onUpdateHabitFocus) {
      onUpdateHabitFocus(effectiveTargetId, mins, false);
    } else if (effectiveTargetType === 'task' && effectiveTargetId && onUpdateTaskFocus) {
      onUpdateTaskFocus(effectiveTargetId, mins, false);
    } else if (onAddGeneralFocus) {
      onAddGeneralFocus(mins);
    }

    if (onRewardCoins && coins > 0) {
      onRewardCoins(coins, `${t.pomodoroManualLogTitle} (${mins} ${t.pomodoroMinutesLabel})`);
    }

    setHistoryRefreshKey((prev) => prev + 1);
    setManualSuccessMsg(
      coins > 0
        ? `+${formatNumber(mins, language)} ${t.pomodoroMinutesLabel || 'دقیقه'} (+${formatNumber(coins, language)} 🪙)`
        : `+${formatNumber(mins, language)} ${t.pomodoroMinutesLabel || 'دقیقه'} ${t.pomodoroLoggedSuccess || 'ثبت شد'}`
    );
    setTimeout(() => setManualSuccessMsg(''), 3500);
  };

  // Change sound safely
  const handleSelectSound = (sndId: PomodoroAmbientSound) => {
    if (typeof onAmbientSoundChange === 'function') {
      onAmbientSoundChange(sndId);
    }
    if (typeof setAmbientSound === 'function') {
      setAmbientSound(sndId);
    }
    if (typeof onUpdateSettings === 'function') {
      onUpdateSettings({ pomodoroAmbientSound: sndId });
    }
    if (sndId === 'none') {
      stopAmbientSound();
    }
  };

  // Progress Calculation
  const safeTotalDuration =
    totalDuration && totalDuration > 0
      ? totalDuration
      : normalizedMode === 'short_break'
      ? (advancedSettings?.pomodoroShortBreakDuration || pomodoroConfig?.shortBreakMinutes || 5) * 60
      : normalizedMode === 'long_break'
      ? (advancedSettings?.pomodoroLongBreakDuration || pomodoroConfig?.longBreakMinutes || 15) * 60
      : (advancedSettings?.pomodoroFocusDuration || pomodoroConfig?.focusMinutes || 25) * 60;

  // For countdowns: progressPercent represents remaining time proportion (100% -> 0%)
  // For stopwatch: progressPercent represents cumulative focus time filled continuously across a standard 60-minute block (0% -> 100%)
  const progressPercent =
    normalizedMode === 'stopwatch'
      ? Math.min(100, Math.max(0, (timeLeft / 3600) * 100))
      : safeTotalDuration > 0
      ? Math.min(100, Math.max(0, (timeLeft / safeTotalDuration) * 100))
      : 100;

  const hoursDisplay = Math.floor(timeLeft / 3600);
  const minutesDisplay = Math.floor((timeLeft % 3600) / 60);
  const secondsDisplay = timeLeft % 60;

  const timeFormatted =
    hoursDisplay > 0
      ? `${formatNumber(String(hoursDisplay).padStart(2, '0'), language)}:${formatNumber(
          String(minutesDisplay).padStart(2, '0'),
          language
        )}:${formatNumber(String(secondsDisplay).padStart(2, '0'), language)}`
      : `${formatNumber(String(minutesDisplay).padStart(2, '0'), language)}:${formatNumber(
          String(secondsDisplay).padStart(2, '0'),
          language
        )}`;

  const modeStyles: Record<PomodoroMode, { badge: string; circle: string; text: string; bg: string }> = {
    focus: {
      badge: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950/80 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
      circle: 'text-indigo-600 dark:text-indigo-400',
      text: 'text-indigo-600 dark:text-indigo-400',
      bg: 'bg-indigo-600 hover:bg-indigo-700 text-white',
    },
    short_break: {
      badge: 'bg-teal-100 text-teal-800 dark:bg-teal-950/80 dark:text-teal-300 border-teal-200 dark:border-teal-800',
      circle: 'text-teal-500 dark:text-teal-400',
      text: 'text-teal-600 dark:text-teal-400',
      bg: 'bg-teal-600 hover:bg-teal-700 text-white',
    },
    long_break: {
      badge: 'bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300 border-purple-200 dark:border-purple-800',
      circle: 'text-purple-500 dark:text-purple-400',
      text: 'text-purple-600 dark:text-purple-400',
      bg: 'bg-purple-600 hover:bg-purple-700 text-white',
    },
    stopwatch: {
      badge: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950/80 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800',
      circle: 'text-cyan-500 dark:text-cyan-400',
      text: 'text-cyan-600 dark:text-cyan-400',
      bg: 'bg-cyan-600 hover:bg-cyan-700 text-white',
    },
  };

  const currentStyle = modeStyles[normalizedMode] || modeStyles.focus;

  if (!isOpen) return null;

  return (
    <div
      id="pomodoro-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="pomodoro-modal-content"
        dir={t.dir}
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-900/50">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                {t.pomodoroModalTitle || 'پایگاه تمرکز پومودورو'}
                <span className="text-xs px-2.5 py-0.5 rounded-full font-normal border border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400">
                  {formatNumber(effectiveCompletedSessions, language)} {t.pomodoroSessionsCount || 'جلسه'}
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 hidden sm:block">
                {t.pomodoroModalSubtitle || 'تکنیک تمرکز عمیق، مدیریت زمان و بهره‌وری بالا'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              id="pomodoro-minimize-btn"
              onClick={onClose}
              title={t.pomodoroFloatingTimerTip || 'کوچک‌نمایی و ادامه در پس‌زمینه'}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
            <button
              id="pomodoro-close-btn"
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Top Tabs */}
        <div className="flex items-center px-6 pt-3 border-b border-slate-100 dark:border-slate-800 gap-2 bg-white dark:bg-slate-900">
          <button
            id="pomodoro-tab-timer-btn"
            onClick={() => setActiveTab('timer')}
            className={`pb-3 px-3 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'timer'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <Timer className="w-4 h-4" />
            <span>{t.pomodoroFocusMode || 'تایمر تمرکز'}</span>
          </button>
          <button
            id="pomodoro-tab-history-btn"
            onClick={() => setActiveTab('history')}
            className={`pb-3 px-3 text-sm font-semibold border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'history'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 dark:border-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>{t.pomodoroHistoryTitle || 'تاریخچه و گزارش‌ها'}</span>
            {stats.todaySessionsCount > 0 && (
              <span className="px-1.5 py-0.2 text-[11px] rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-300 font-bold">
                {formatNumber(stats.todaySessionsCount, language)}
              </span>
            )}
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'timer' ? (
            <>
              {/* Target Selector Bar */}
              <div className="relative">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Target className="w-3.5 h-3.5 text-indigo-500" />
                    {t.pomodoroTargetLabel || 'هدف این جلسه تمرکز:'}
                  </span>
                  {effectiveTargetType === 'habit' && currentHabit && (
                    <span className="text-[11px] font-normal text-slate-500">
                      {formatNumber(currentHabit.totalFocusMinutes || 0, language)}{' '}
                      {t.pomodoroMinutesLabel || 'دقیقه'} {t.pomodoroHabitFocusBadge || 'ثبت شده'}
                    </span>
                  )}
                  {effectiveTargetType === 'task' && currentTask && (
                    <span className="text-[11px] font-normal text-slate-500">
                      {formatNumber(currentTask.totalFocusMinutes || 0, language)}{' '}
                      {t.pomodoroMinutesLabel || 'دقیقه'} {t.pomodoroTaskFocusBadge || 'ثبت شده'}
                    </span>
                  )}
                </div>

                {/* Target Dropdown Button */}
                <button
                  id="pomodoro-target-dropdown-toggle"
                  type="button"
                  onClick={() => setTargetDropdownOpen(!targetDropdownOpen)}
                  className="w-full flex items-center justify-between px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 text-sm font-medium text-slate-800 dark:text-slate-100 hover:border-indigo-400 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <div
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ backgroundColor: activeTargetColor }}
                    />
                    <span className="truncate font-semibold">{activeTargetName}</span>
                    <span className="text-xs px-2 py-0.5 rounded-md bg-slate-200/60 dark:bg-slate-700/60 text-slate-600 dark:text-slate-300">
                      {effectiveTargetType === 'habit'
                        ? t.pomodoroHabitsGroup || 'عادت'
                        : effectiveTargetType === 'task'
                        ? t.pomodoroTasksGroup || 'تسک'
                        : t.pomodoroNoTarget || 'تمرکز آزاد'}
                    </span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {targetDropdownOpen && (
                  <div
                    id="pomodoro-target-dropdown-menu"
                    className="absolute z-20 top-full mt-1.5 w-full max-h-72 overflow-y-auto rounded-2xl bg-white dark:bg-slate-850 border border-slate-200 dark:border-slate-700 shadow-2xl p-2.5 space-y-2"
                  >
                    {/* Search & Filter Bar inside Target Dropdown */}
                    <div className="space-y-1.5 pb-1 border-b border-slate-100 dark:border-slate-750">
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 absolute top-1/2 -translate-y-1/2 start-2.5 text-slate-400" />
                        <input
                          type="text"
                          value={targetSearchQuery}
                          onChange={(e) => setTargetSearchQuery(e.target.value)}
                          placeholder={language === 'fa' ? 'جستجو در عادات و تسک‌ها...' : 'Search habits or tasks...'}
                          className="w-full ps-8 pe-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
                        />
                      </div>

                      <div className="flex items-center gap-1 text-[11px]">
                        <button
                          type="button"
                          onClick={() => setTargetFilterTab('all')}
                          className={`px-2 py-0.5 rounded-lg font-bold transition cursor-pointer ${
                            targetFilterTab === 'all'
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                          }`}
                        >
                          {language === 'fa' ? 'همه' : 'All'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setTargetFilterTab('habit')}
                          className={`px-2 py-0.5 rounded-lg font-bold transition cursor-pointer ${
                            targetFilterTab === 'habit'
                              ? 'bg-blue-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                          }`}
                        >
                          {language === 'fa' ? 'عادات' : 'Habits'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setTargetFilterTab('task')}
                          className={`px-2 py-0.5 rounded-lg font-bold transition cursor-pointer ${
                            targetFilterTab === 'task'
                              ? 'bg-indigo-600 text-white'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                          }`}
                        >
                          {language === 'fa' ? 'تسک‌ها' : 'Tasks'}
                        </button>
                      </div>
                    </div>

                    {/* Free Focus / No Target */}
                    {targetFilterTab === 'all' && !targetSearchQuery && (
                      <button
                        type="button"
                        onClick={() => handleSelectTarget('none', null)}
                        className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold text-start transition-colors cursor-pointer ${
                          effectiveTargetType === 'none'
                            ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300'
                            : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700/50'
                        }`}
                      >
                        <span className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
                          {t.pomodoroNoTarget || 'تمرکز آزاد (بدون اتصال به هدف خاص)'}
                        </span>
                        {effectiveTargetType === 'none' && <Check className="w-4 h-4" />}
                      </button>
                    )}

                    {/* Habits Section */}
                    {(targetFilterTab === 'all' || targetFilterTab === 'habit') && habits.length > 0 && (
                      <div className="pt-1">
                        <div className="px-2 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          {t.pomodoroHabitsGroup || 'عادات ۶۶ روزه'}
                        </div>
                        {habits
                          .filter((h) => !targetSearchQuery || h.name.toLowerCase().includes(targetSearchQuery.toLowerCase()))
                          .map((h) => (
                            <button
                              key={h.id}
                              type="button"
                              onClick={() => handleSelectTarget('habit', h.id)}
                              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-start transition-colors cursor-pointer ${
                                effectiveTargetType === 'habit' && effectiveTargetId === h.id
                                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300 font-bold'
                                  : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-750'
                              }`}
                            >
                              <span className="flex items-center gap-2 truncate">
                                <span
                                  className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                                  style={{ backgroundColor: h.color || '#3b82f6' }}
                                />
                                <span className="truncate">{h.name}</span>
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {formatNumber(h.totalFocusMinutes || 0, language)}m
                              </span>
                            </button>
                          ))}
                      </div>
                    )}

                    {/* Tasks Section */}
                    {(targetFilterTab === 'all' || targetFilterTab === 'task') && tasks.length > 0 && (
                      <div className="pt-1 border-t border-slate-100 dark:border-slate-750">
                        <div className="px-2 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                          {t.pomodoroTasksGroup || 'تسک‌ها و کارهای روزمره'}
                        </div>
                        {tasks
                          .filter((tsk) => !targetSearchQuery || tsk.title.toLowerCase().includes(targetSearchQuery.toLowerCase()))
                          .map((tsk) => (
                            <button
                              key={tsk.id}
                              type="button"
                              onClick={() => handleSelectTarget('task', tsk.id)}
                              className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium text-start transition-colors cursor-pointer ${
                                effectiveTargetType === 'task' && effectiveTargetId === tsk.id
                                  ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300 font-bold'
                                  : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-750'
                              }`}
                            >
                              <span className="flex items-center gap-2 truncate">
                                <span
                                  className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                                  style={{ backgroundColor: tsk.color || '#10b981' }}
                                />
                                <span className={`truncate ${tsk.completed ? 'line-through text-slate-400' : ''}`}>
                                  {tsk.title}
                                </span>
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono">
                                {formatNumber(tsk.totalFocusMinutes || 0, language)}m
                              </span>
                            </button>
                          ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Mode Switcher Buttons */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <button
                  id="pomo-mode-focus-btn"
                  onClick={() => handleSwitchMode('focus')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                    normalizedMode === 'focus'
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>{t.pomodoroFocusMode || 'تمرکز (۲۵ دقیقه)'}</span>
                </button>

                <button
                  id="pomo-mode-short-break-btn"
                  onClick={() => handleSwitchMode('short_break')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                    normalizedMode === 'short_break'
                      ? 'bg-teal-600 text-white shadow-md shadow-teal-600/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Coffee className="w-3.5 h-3.5" />
                  <span>{t.pomodoroShortBreak || 'استراحت کوتاه (۵)'}</span>
                </button>

                <button
                  id="pomo-mode-long-break-btn"
                  onClick={() => handleSwitchMode('long_break')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                    normalizedMode === 'long_break'
                      ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Sun className="w-3.5 h-3.5" />
                  <span>{t.pomodoroLongBreak || 'استراحت طولانی (۱۵)'}</span>
                </button>

                <button
                  id="pomo-mode-stopwatch-btn"
                  onClick={() => handleSwitchMode('stopwatch')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-2xl text-xs font-bold transition-all cursor-pointer ${
                    normalizedMode === 'stopwatch'
                      ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/20'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                  }`}
                >
                  <Timer className="w-3.5 h-3.5" />
                  <span>{t.pomodoroStopwatch || 'کرنومتر'}</span>
                </button>
              </div>

              {/* Main Timer Display Ring - Chronograph Styled */}
              <div className="flex flex-col items-center justify-center py-3">
                <div className="relative w-60 h-60 sm:w-68 sm:h-68 flex items-center justify-center select-none">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 240 240">
                    <defs>
                      {/* Gradients for each mode */}
                      <linearGradient id="focusGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#818cf8" />
                        <stop offset="100%" stopColor="#4f46e5" />
                      </linearGradient>
                      <linearGradient id="shortBreakGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#2dd4bf" />
                        <stop offset="100%" stopColor="#0d9488" />
                      </linearGradient>
                      <linearGradient id="longBreakGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#c084fc" />
                        <stop offset="100%" stopColor="#9333ea" />
                      </linearGradient>
                      <linearGradient id="stopwatchGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#38bdf8" />
                        <stop offset="100%" stopColor="#0284c7" />
                      </linearGradient>

                      {/* Subtle drop shadow filter for glowing effect */}
                      <filter id="timerGlow" x="-20%" y="-20%" width="140%" height="140%">
                        <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor={
                          normalizedMode === 'focus' ? '#6366f1' :
                          normalizedMode === 'short_break' ? '#14b8a6' :
                          normalizedMode === 'long_break' ? '#a855f7' : '#06b6d4'
                        } floodOpacity="0.35" />
                      </filter>
                    </defs>

                    {/* Outer Decorative Track */}
                    <circle
                      cx="120"
                      cy="120"
                      r="108"
                      className="stroke-slate-200/50 dark:stroke-slate-800/60"
                      strokeWidth="1.5"
                      strokeDasharray="2 4"
                      fill="none"
                    />

                    {/* 60 Chronograph Tick Marks */}
                    {Array.from({ length: 60 }).map((_, i) => {
                      const angle = (i * 6 * Math.PI) / 180;
                      const isMajor = i % 5 === 0;
                      const r1 = isMajor ? 98 : 101;
                      const r2 = 105;
                      const x1 = 120 + r1 * Math.cos(angle);
                      const y1 = 120 + r1 * Math.sin(angle);
                      const x2 = 120 + r2 * Math.cos(angle);
                      const y2 = 120 + r2 * Math.sin(angle);
                      return (
                        <line
                          key={i}
                          x1={x1}
                          y1={y1}
                          x2={x2}
                          y2={y2}
                          className={
                            isMajor
                              ? 'stroke-slate-400/80 dark:stroke-slate-500/80'
                              : 'stroke-slate-200 dark:stroke-slate-800'
                          }
                          strokeWidth={isMajor ? 2 : 1}
                          strokeLinecap="round"
                        />
                      );
                    })}

                    {/* Background Progress Circle */}
                    <circle
                      cx="120"
                      cy="120"
                      r="90"
                      className="stroke-slate-100 dark:stroke-slate-800/80"
                      strokeWidth="10"
                      fill="none"
                    />

                    {/* Active Animated Progress Arc */}
                    <circle
                      cx="120"
                      cy="120"
                      r="90"
                      stroke={
                        normalizedMode === 'focus'
                          ? 'url(#focusGradient)'
                          : normalizedMode === 'short_break'
                          ? 'url(#shortBreakGradient)'
                          : normalizedMode === 'long_break'
                          ? 'url(#longBreakGradient)'
                          : 'url(#stopwatchGradient)'
                      }
                      strokeWidth="10"
                      strokeDasharray={565.487}
                      strokeDashoffset={565.487 * (1 - progressPercent / 100)}
                      strokeLinecap="round"
                      filter={isRunning ? 'url(#timerGlow)' : undefined}
                      className="transition-all duration-700 ease-out"
                      fill="none"
                    />
                  </svg>

                  {/* Inner Timer Content */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-3">
                    {/* Status Badge */}
                    <div
                      className={`inline-flex items-center gap-1.5 px-3 py-0.8 rounded-full text-xs font-bold border mb-1 shadow-xs transition-colors ${currentStyle.badge}`}
                    >
                      {isRunning && (
                        <span className="w-2 h-2 rounded-full bg-current animate-ping opacity-75" />
                      )}
                      <span>
                        {normalizedMode === 'focus'
                          ? t.pomodoroFocusMode || 'تمرکز'
                          : normalizedMode === 'short_break'
                          ? t.pomodoroShortBreak || 'استراحت کوتاه'
                          : normalizedMode === 'long_break'
                          ? t.pomodoroLongBreak || 'استراحت طولانی'
                          : t.pomodoroStopwatch || 'کرنومتر'}
                      </span>
                    </div>

                    {/* Main Time Counter */}
                    <span className="text-4xl sm:text-5xl font-mono font-black text-slate-900 dark:text-white tracking-tighter my-0.5 tabular-nums drop-shadow-xs">
                      {timeFormatted}
                    </span>

                    {/* Target Indicator */}
                    <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-xl bg-slate-100/80 dark:bg-slate-800/80 max-w-[190px] border border-slate-200/50 dark:border-slate-700/50">
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{ backgroundColor: activeTargetColor }}
                      />
                      <span
                        className="text-[11px] font-semibold truncate text-slate-700 dark:text-slate-200"
                        title={activeTargetName}
                      >
                        {activeTargetName}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Duration Presets & Steppers (when paused/focus) */}
                {normalizedMode !== 'stopwatch' && !isRunning && (
                  <div className="flex items-center gap-1.5 mt-3 flex-wrap justify-center animate-fade-in">
                    <button
                      onClick={() => handleAdjustTime(-5)}
                      className="px-2.5 py-1 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1 font-semibold cursor-pointer transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                      <span>{t.pomodoroSub5Min || '-۵ دقیقه'}</span>
                    </button>
                    <button
                      onClick={() => handleSetPreset(15)}
                      className={`px-3 py-1 text-xs rounded-xl font-bold cursor-pointer transition-all ${
                        Math.round(timeLeft / 60) === 15
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      {t.pomodoroPreset15 || '۱۵ د'}
                    </button>
                    <button
                      onClick={() => handleSetPreset(25)}
                      className={`px-3 py-1 text-xs rounded-xl font-bold cursor-pointer transition-all ${
                        Math.round(timeLeft / 60) === 25
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      {t.pomodoroPreset25 || '۲۵ د'}
                    </button>
                    <button
                      onClick={() => handleSetPreset(45)}
                      className={`px-3 py-1 text-xs rounded-xl font-bold cursor-pointer transition-all ${
                        Math.round(timeLeft / 60) === 45
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      {t.pomodoroPreset45 || '۴۵ د'}
                    </button>
                    <button
                      onClick={() => handleSetPreset(60)}
                      className={`px-3 py-1 text-xs rounded-xl font-bold cursor-pointer transition-all ${
                        Math.round(timeLeft / 60) === 60
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                      }`}
                    >
                      ۶۰ د
                    </button>
                    <button
                      onClick={() => handleAdjustTime(5)}
                      className="px-2.5 py-1 text-xs rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center gap-1 font-semibold cursor-pointer transition-colors"
                    >
                      <Plus className="w-3 h-3" />
                      <span>{t.pomodoroAdd5Min || '+۵ دقیقه'}</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Main Action Buttons */}
              <div className="flex items-center justify-center gap-3">
                <button
                  id="pomodoro-reset-btn"
                  onClick={handleResetClick}
                  title={t.pomodoroReset || 'تنظیم مجدد'}
                  className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-transform active:scale-95 cursor-pointer"
                >
                  <RotateCcw className="w-5 h-5" />
                </button>

                <button
                  id="pomodoro-main-toggle-btn"
                  onClick={handleTogglePlay}
                  className={`px-8 py-3.5 rounded-2xl font-bold text-base shadow-lg transition-transform active:scale-95 flex items-center gap-2.5 cursor-pointer ${currentStyle.bg}`}
                >
                  {isRunning ? (
                    <>
                      <Pause className="w-5 h-5" />
                      <span>{t.pomodoroPause || 'توقف'}</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 fill-current" />
                      <span>
                        {timeLeft < safeTotalDuration && timeLeft > 0
                          ? t.pomodoroResume || 'ادامه'
                          : t.pomodoroStart || 'شروع'}
                      </span>
                    </>
                  )}
                </button>

                <button
                  id="pomodoro-skip-btn"
                  onClick={handleSessionFinished}
                  title={t.pomodoroSkip || 'پایان و ثبت جلسه'}
                  className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-transform active:scale-95 cursor-pointer"
                >
                  <SkipForward className="w-5 h-5" />
                </button>
              </div>

              {/* Ambient Focus Sound Controls (Custom Uploaded Sounds) */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/70 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span className="flex items-center gap-1.5">
                    {ambientSound !== 'none' ? (
                      <Volume2 className="w-4 h-4 text-indigo-500" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-slate-400" />
                    )}
                    <span>{language === 'fa' ? 'صدای پس‌زمینه تمرکز (شخصی‌سازی شده)' : language === 'ar' ? 'صوت الخلفية للتركيز' : 'Custom Ambient Focus Sound'}</span>
                  </span>

                  <div className="flex items-center gap-2">
                    {ambientSound !== 'none' && isRunning && (
                      <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-normal animate-pulse flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        {language === 'fa' 
                          ? `در حال پخش: ${customSounds.find((s) => s.id === ambientSound)?.name || t.pomodoroSoundNone || 'خاموش'}` 
                          : `Playing: ${customSounds.find((s) => s.id === ambientSound)?.name || 'Custom'}`}
                      </span>
                    )}

                    {onOpenSettings && (
                      <button
                        type="button"
                        onClick={onOpenSettings}
                        className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-medium cursor-pointer"
                        title={language === 'fa' ? 'آپلود و مدیریت صداها در تنظیمات پیشرفته' : 'Manage sounds in settings'}
                      >
                        <Sliders className="w-3 h-3" />
                        <span>{language === 'fa' ? 'مدیریت صداها' : language === 'ar' ? 'إدارة الأصوات' : 'Manage Sounds'}</span>
                      </button>
                    )}
                  </div>
                </div>

                {customSounds.length === 0 ? (
                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-dashed border-slate-200 dark:border-slate-700/80 flex flex-col sm:flex-row items-center justify-between gap-2.5 text-center sm:text-start">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-500 shrink-0">
                        <Music className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {language === 'fa' ? 'هنوز فایل صوتی آپلود نشده است' : language === 'ar' ? 'لم يتم رفع ملفات صوتية بعد' : 'No custom sounds uploaded yet'}
                        </p>
                        <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {language === 'fa' 
                            ? 'برای افزودن موزیک یا فایل صوتی آرامش‌بخش دلخواه خود، به بخش تنظیمات پیشرفته بروید.'
                            : language === 'ar'
                            ? 'لإضافة مقاطع صوتية مخصصة، انتقل إلى الإعدادات المتقدمة.'
                            : 'Upload your favorite ambient audio files in Advanced Settings to play during focus sessions.'}
                        </p>
                      </div>
                    </div>
                    {onOpenSettings && (
                      <button
                        type="button"
                        onClick={onOpenSettings}
                        className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition shadow-xs cursor-pointer shrink-0"
                      >
                        {language === 'fa' ? 'تنظیمات پیشرفته ↗' : language === 'ar' ? 'الإعدادات المتقدمة ↗' : 'Go to Settings ↗'}
                      </button>
                    )}
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 max-h-36 overflow-y-auto pr-0.5">
                      {/* Mute button */}
                      <button
                        type="button"
                        onClick={() => handleSelectSound('none')}
                        className={`px-2.5 py-2 rounded-xl text-[11px] font-semibold text-center truncate transition-all cursor-pointer flex items-center justify-center gap-1.5 border ${
                          ambientSound === 'none'
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                            : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                        }`}
                      >
                        <VolumeX className="w-3.5 h-3.5 shrink-0" />
                        <span className="truncate">{t.pomodoroSoundNone || 'خاموش'}</span>
                      </button>

                      {/* Custom uploaded sounds */}
                      {customSounds.map((snd) => (
                        <button
                          key={snd.id}
                          type="button"
                          onClick={() => handleSelectSound(snd.id)}
                          className={`px-2.5 py-2 rounded-xl text-[11px] font-semibold text-center truncate transition-all cursor-pointer flex items-center justify-center gap-1.5 border ${
                            ambientSound === snd.id
                              ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                          }`}
                          title={snd.name}
                        >
                          <Music className="w-3 h-3 shrink-0" />
                          <span className="truncate">{snd.name}</span>
                        </button>
                      ))}
                    </div>

                    {/* Volume Slider when sound is selected */}
                    {ambientSound !== 'none' && onVolumeChange && (
                      <div className="flex items-center gap-3 pt-1 border-t border-slate-200/50 dark:border-slate-800/60">
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium flex items-center gap-1 shrink-0">
                          <Volume2 className="w-3 h-3 text-indigo-500" />
                          <span>{language === 'fa' ? 'میزان بلندی صدا:' : 'Volume:'}</span>
                        </span>
                        <input
                          id="pomodoro-sound-volume-slider"
                          type="range"
                          min="0.05"
                          max="1"
                          step="0.05"
                          value={soundVolume}
                          onChange={(e) => onVolumeChange(parseFloat(e.target.value))}
                          className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg"
                        />
                        <span className="text-[10px] font-mono text-slate-600 dark:text-slate-300 font-bold shrink-0">
                          {Math.round(soundVolume * 100)}%
                        </span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Manual Time & Focus Logger Card */}
              <div className="p-4 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <h3 className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      {t.pomodoroManualLogTitle || 'ثبت دستی دقایق تمرکز'}
                    </h3>
                  </div>
                  {manualSuccessMsg && (
                    <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 animate-fade-in flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {manualSuccessMsg}
                    </span>
                  )}
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  {t.pomodoroManualLogDesc ||
                    'اگر بدون روشن کردن تایمر مطالعه یا تمرکز داشته‌اید، می‌توانید دقایق را دستی ثبت کنید:'}
                </p>

                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-xs font-medium text-slate-600 dark:text-slate-400">
                    {t.pomodoroQuickAddMinutes || 'افزودن سریع:'}
                  </span>
                  {[15, 25, 30, 45, 60].map((mins) => (
                    <button
                      key={mins}
                      onClick={() => handleManualLog(mins)}
                      className="px-3 py-1 text-xs font-bold rounded-xl bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 shadow-sm transition-transform active:scale-95 cursor-pointer"
                    >
                      +{formatNumber(mins, language)} {t.pomodoroMinutesLabel || 'دقیقه'}
                    </button>
                  ))}
                </div>
              </div>
            </>
          ) : (
            /* History & Analytics Tab */
            <div className="space-y-5">
              {/* Daily KPI summary cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50">
                  <div className="text-xs text-slate-500 dark:text-slate-400 mb-1 font-medium">
                    {t.pomodoroTodayTotalFocus || 'تمرکز امروز'}
                  </div>
                  <div className="text-xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
                    {formatNumber(stats.todayMinutes, language)}{' '}
                    <span className="text-xs font-normal text-slate-500">
                      {t.pomodoroMinutesLabel || 'دقیقه'}
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-100 dark:border-teal-900/50">
                  <div className="text-xs text-slate-500 dark:text-slate-400 mb-1 font-medium">
                    {t.pomodoroTotalFocusAllTime || 'مجموع کل تمرکز'}
                  </div>
                  <div className="text-xl font-bold font-mono text-teal-600 dark:text-teal-400">
                    {formatNumber(stats.totalMinutes, language)}{' '}
                    <span className="text-xs font-normal text-slate-500">
                      {t.pomodoroMinutesLabel || 'دقیقه'}
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-amber-50/70 dark:bg-amber-950/40 border border-amber-100 dark:border-amber-900/50">
                  <div className="text-xs text-slate-500 dark:text-slate-400 mb-1 font-medium">
                    {t.pomodoroSessionsCount || 'تعداد جلسات'}
                  </div>
                  <div className="text-xl font-bold font-mono text-amber-600 dark:text-amber-400">
                    {formatNumber(stats.totalSessionsCount, language)}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-purple-50/70 dark:bg-purple-950/40 border border-purple-100 dark:border-purple-900/50">
                  <div className="text-xs text-slate-500 dark:text-slate-400 mb-1 font-medium">
                    {t.pomodoroHabitsGroup || 'عادات'}
                  </div>
                  <div className="text-xl font-bold font-mono text-purple-600 dark:text-purple-400">
                    {formatNumber(stats.habitMinutesTotal, language)}{' '}
                    <span className="text-xs font-normal text-slate-500">
                      {t.pomodoroMinutesLabel || 'دقیقه'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Sessions List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
                    {t.pomodoroHistoryTitle || 'تاریخچه جلسات اخیر'}
                  </h3>
                  {sessions.length > 0 && (
                    <button
                      onClick={() => {
                        clearPomodoroSessions();
                        setHistoryRefreshKey((prev) => prev + 1);
                      }}
                      className="text-xs text-rose-500 hover:text-rose-600 flex items-center gap-1 font-medium cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>{t.pomodoroClearHistory || 'پاکسازی تاریخچه'}</span>
                    </button>
                  )}
                </div>

                {sessions.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-sm">
                    {t.pomodoroNoSessionsYet || 'هنوز جلسه‌ای ثبت نشده است.'}
                  </div>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800/80 max-h-80 overflow-y-auto rounded-2xl border border-slate-200/80 dark:border-slate-800 bg-white dark:bg-slate-900/50">
                    {sessions.map((ses) => {
                      const isFull = ses.isCompletedFull || ses.durationMinutes >= 25;
                      const hasSeconds = typeof ses.durationSeconds === 'number' && ses.durationSeconds > 0;
                      const durSec = hasSeconds ? ses.durationSeconds! : ses.durationMinutes * 60;
                      const formattedDur = formatPomodoroDuration(durSec, language, true);

                      return (
                        <div
                          key={ses.id}
                          className="flex items-center justify-between p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors text-xs gap-2"
                        >
                          <div className="flex items-center gap-2.5 min-w-0 flex-1">
                            <div
                              className={`p-2 rounded-xl flex-shrink-0 ${
                                isFull
                                  ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400'
                                  : 'bg-amber-50 text-amber-600 dark:bg-amber-950/60 dark:text-amber-400'
                              }`}
                            >
                              <Clock className="w-4 h-4" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                                  {ses.targetName || ses.targetTitle || t.pomodoroNoTarget || 'تمرکز آزاد'}
                                </span>
                                <span
                                  className={`text-[10px] px-1.5 py-0.5 rounded-full font-medium ${
                                    isFull
                                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300'
                                      : 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'
                                  }`}
                                >
                                  {isFull
                                    ? (language === 'fa' ? 'تکمیل ۲۵دقیقه' : 'Completed 25m')
                                    : (language === 'fa' ? 'پایان زودهنگام' : 'Early finished')}
                                </span>
                              </div>
                              <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5 flex-wrap">
                                <span>{ses.completedAt}</span>
                                {ses.time && <span>• {ses.time}</span>}
                                <span>
                                  •{' '}
                                  {ses.mode === 'focus'
                                    ? t.pomodoroFocusMode || 'تمرکز'
                                    : t.pomodoroStopwatch || 'کرنومتر'}
                                </span>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-2.5 font-mono flex-shrink-0">
                            <div className="text-end">
                              <div className="font-bold text-indigo-600 dark:text-indigo-400">
                                {formattedDur}
                              </div>
                              {ses.rewardCoinsEarned && ses.rewardCoinsEarned > 0 ? (
                                <div className="text-[10px] text-amber-500 font-bold">
                                  +{formatNumber(ses.rewardCoinsEarned, language)} 🪙
                                </div>
                              ) : null}
                            </div>
                            <button
                              onClick={() => {
                                deletePomodoroSession(ses.id);
                                setHistoryRefreshKey((prev) => prev + 1);
                              }}
                              className="text-slate-300 hover:text-rose-500 p-1.5 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                              title={t.delete || 'حذف'}
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/50 flex items-center justify-between">
          <span className="text-xs text-slate-400">
            {t.pomodoroFloatingTimerTip || 'می‌توانید پنجره را ببندید، تایمر در پس‌زمینه ادامه می‌یابد.'}
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-900 dark:bg-slate-700 dark:hover:bg-slate-600 text-white transition-colors cursor-pointer"
          >
            بستن و ادامه در پس‌زمینه
          </button>
        </div>
      </div>

      {/* Session Completion Celebration Dialog */}
      {showCompletionModal && lastFinishedSession && (
        <div
          id="pomodoro-celebration-dialog"
          className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in"
        >
          <div
            dir={t.dir}
            className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-center space-y-4"
          >
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-indigo-600 mx-auto flex items-center justify-center text-white shadow-xl shadow-indigo-500/20 animate-bounce">
              <Award className="w-8 h-8" />
            </div>

            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-slate-50">
                {t.pomodoroSessionCompleted || 'جلسه تمرکز با موفقیت به پایان رسید!'}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {formatNumber(lastFinishedSession.minutes, language)} {t.pomodoroMinutesLabel || 'دقیقه'}{' '}
                {t.pomodoroFocusMode || 'تمرکز'} برای «{lastFinishedSession.targetName}»
              </p>
            </div>

            {/* Rewards Card or Early Finish Notice */}
            {lastFinishedSession.coins > 0 || lastFinishedSession.xp > 0 ? (
              <div className="p-3.5 rounded-2xl bg-amber-50/80 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 flex items-center justify-center gap-6">
                <div className="text-center">
                  <span className="block text-2xl font-black text-amber-600 dark:text-amber-400 font-mono">
                    +{formatNumber(lastFinishedSession.coins, language)}
                  </span>
                  <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300">
                    {t.pomodoroCoinsEarned || 'سکه پاداش'} 🪙
                  </span>
                </div>
                <div className="w-px h-8 bg-amber-200 dark:bg-amber-800" />
                <div className="text-center">
                  <span className="block text-2xl font-black text-indigo-600 dark:text-indigo-400 font-mono">
                    +{formatNumber(lastFinishedSession.xp, language)}
                  </span>
                  <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300">
                    {t.pomodoroXpEarned || 'امتیاز تجربه'} ⭐
                  </span>
                </div>
              </div>
            ) : (
              <div className="p-3 rounded-2xl bg-slate-100 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 text-center space-y-1">
                <div className="text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5">
                  <Clock className="w-4 h-4 text-indigo-500" />
                  <span>
                    {formatNumber(lastFinishedSession.minutes, language)} {t.pomodoroMinutesLabel || 'دقیقه'} {t.pomodoroLoggedSuccess || 'ثبت شد'}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {t.pomodoroEarlyFinishNotice ||
                    'جلسه قبل از ۲۵ دقیقه پایان یافت. زمان واقعی ثبت شد اما پاداش سکه و XP تنها به جلسات ۲۵ دقیقه به بالا تعلق می‌گیرد.'}
                </p>
              </div>
            )}

            {/* Prompts for Habit / Task Check-in */}
            {lastFinishedSession.targetType === 'habit' && lastFinishedSession.targetId && (
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs">
                <p className="text-slate-700 dark:text-slate-200 mb-2 font-medium">
                  {t.pomodoroMarkHabitDonePrompt || 'آیا مایلید تیک امروز این عادت ثبت شود؟'}
                </p>
                <button
                  onClick={() => {
                    if (lastFinishedSession.targetId) {
                      if (onCompleteHabit) {
                        onCompleteHabit(lastFinishedSession.targetId);
                      } else if (onUpdateHabitFocus) {
                        onUpdateHabitFocus(lastFinishedSession.targetId, 0, true);
                      }
                    }
                    setShowCompletionModal(false);
                  }}
                  className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>ثبت تیک امروز (انجام شد)</span>
                </button>
              </div>
            )}

            {lastFinishedSession.targetType === 'task' && lastFinishedSession.targetId && (
              <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs">
                <p className="text-slate-700 dark:text-slate-200 mb-2 font-medium">
                  {t.pomodoroMarkTaskDonePrompt || 'آیا مایلید وضعیت این تسک به پایان‌یافته تغییر کند؟'}
                </p>
                <button
                  onClick={() => {
                    if (lastFinishedSession.targetId) {
                      if (onCompleteTask) {
                        onCompleteTask(lastFinishedSession.targetId);
                      } else if (onUpdateTaskFocus) {
                        onUpdateTaskFocus(lastFinishedSession.targetId, 0, true);
                      }
                    }
                    setShowCompletionModal(false);
                  }}
                  className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>تکمیل و بستن تسک</span>
                </button>
              </div>
            )}

            <button
              onClick={() => setShowCompletionModal(false)}
              className="w-full py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
            >
              عالی، بازگشت به تایمر
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
