import JSZip from 'jszip';
import { WebNovelChapter, Language } from '../types';
import { getStoredSectionAIKeys } from './aiKeyManager';

// Convert Persian/Arabic digits to standard ASCII digits
export const normalizeDigits = (str: string): string => {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const arabicDigits = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  let res = str;
  for (let i = 0; i < 10; i++) {
    res = res.split(persianDigits[i]).join(String(i));
    res = res.split(arabicDigits[i]).join(String(i));
  }
  return res;
};

// Persian and English ordinal words to numbers
const WORD_NUMBERS: Record<string, number> = {
  'اول': 1, 'نخست': 1, 'دوم': 2, 'سوم': 3, 'چهارم': 4, 'پنجم': 5,
  'ششم': 6, 'هفتم': 7, 'هشتم': 8, 'نهم': 9, 'دهم': 10,
  'یازدهم': 11, 'دوازدهم': 12, 'سیزدهم': 13, 'چهاردهم': 14, 'پانزدهم': 15,
  'شانزدهم': 16, 'هفدهم': 17, 'هجدهم': 18, 'نوزدهم': 19, 'بیستم': 20,
  'بیست و یکم': 21, 'بیست و دوم': 22, 'بیست و سوم': 23, 'بیست و چهارم': 24, 'بیست و پنجم': 25,
  'بیست و ششم': 26, 'بیست و هفتم': 27, 'بیست و هشتم': 28, 'بیست و نهم': 29, 'سی ام': 30, 'سی‌ام': 30,
  'چهلم': 40, 'پنجاهم': 50, 'شصتم': 60, 'هفتادم': 70, 'هشتادم': 80, 'نودم': 90, 'صدم': 100,
  'الأول': 1, 'الثاني': 2, 'الثالث': 3, 'الرابع': 4, 'الخامس': 5, 'السادس': 6, 'السابع': 7, 'الثامن': 8, 'التاسع': 9, 'العاشر': 10,
  'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5,
  'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10,
  'eleventh': 11, 'twelfth': 12, 'thirteenth': 13, 'fourteenth': 14, 'fifteenth': 15
};

export interface ParsedFileInfo {
  file: File;
  fileName: string;
  detectedChapterNumber: number | null;
  detectedTitle: string;
  fileSizeFormatted: string;
}

/**
 * Extract chapter number, title, and body from raw plain text content (TXT, MD)
 * Checks the beginning of the file content for chapter heading patterns.
 */
export const extractChapterFromTextContent = (
  rawText: string,
  language: Language = 'fa',
  fallbackIndex: number = 1
): {
  title: string;
  content: string;
  chapterNumber: number | null;
} => {
  const isFa = language === 'fa';
  const isAr = language === 'ar';
  const clean = rawText.trim();
  if (!clean) {
    return {
      title: isFa ? `فصل ${fallbackIndex}` : `Chapter ${fallbackIndex}`,
      content: '',
      chapterNumber: fallbackIndex,
    };
  }

  const lines = clean.split('\n');
  let detectedChapterNum: number | null = null;
  let detectedTitle = '';
  let headerLineIndex = -1;

  // Inspect the first 8 non-empty lines for chapter headers
  let checkedCount = 0;
  for (let i = 0; i < lines.length && checkedCount < 8; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine) continue;
    checkedCount++;

    // Normalize digits (Persian/Arabic to English)
    const normalizedLine = normalizeDigits(rawLine);

    // 1. Asian notation: 第50章 标题 / 50화
    const matchAsian = normalizedLine.match(/(?:第\s*([0-9]{1,5})\s*(?:章|话|回)|([0-9]{1,5})\s*(?:화|장|章|话|回))\s*(.*)/);
    if (matchAsian) {
      detectedChapterNum = parseInt(matchAsian[1] || matchAsian[2], 10);
      const sub = (matchAsian[3] || '').replace(/^[#=*\-_\[\]()~`\s:–—]+/, '').trim();
      detectedTitle = sub ? `${isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`}: ${sub}` : (isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`);
      headerLineIndex = i;
      break;
    }

    // 2. Keyword with digits: فصل 10: عنوان / Chapter 10 - Title / Ch. 10 / Vol 1 Ch 10 / ## Chapter 10
    const keywordRegex = /^(?:[#=*_\-\[\]()~`\s]*)(?:فصل|چپتر|قسمت|بخش|الفصل|باب|chapter|ch\.|ch|part|episode|ep|vol|c)[\s_.-]*([0-9]{1,5})(?:\s*[:\-\—\–.]\s*(.*)|\s*(.*))$/i;
    const matchKeyword = normalizedLine.match(keywordRegex);
    if (matchKeyword) {
      detectedChapterNum = parseInt(matchKeyword[1], 10);
      const sub = (matchKeyword[2] || matchKeyword[3] || '').replace(/^[#=*\-_\[\]()~`\s:–—]+/, '').replace(/[#=*\-_\[\]()~`\s]+$/, '').trim();
      detectedTitle = sub ? `${isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`}: ${sub}` : (isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`);
      headerLineIndex = i;
      break;
    }

    // 3. Word numbers: فصل اول: ... / Chapter One: ...
    let foundWord = false;
    for (const [word, num] of Object.entries(WORD_NUMBERS)) {
      const wordRegex = new RegExp(`^(?:[#=*_\\-\\[\\]()~\`\\s]*)(?:فصل|چپتر|قسمت|الفصل|chapter|ch)[\\s_.-]+${word}(?:\\s*[:\\-\\—\\–.]\\s*(.*)|\\s*(.*))$`, 'i');
      const matchWord = normalizedLine.match(wordRegex);
      if (matchWord) {
        detectedChapterNum = num;
        const sub = (matchWord[1] || matchWord[2] || '').replace(/^[#=*\-_\[\]()~`\s:–—]+/, '').replace(/[#=*\-_\[\]()~`\s]+$/, '').trim();
        detectedTitle = sub ? `${isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`}: ${sub}` : (isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`);
        headerLineIndex = i;
        foundWord = true;
        break;
      }
    }
    if (foundWord) break;

    // 4. Leading number format: "12: The Battle" / "12 - The Attack" / "12. Awakening"
    const leadingNumberRegex = /^(?:[#=*_\-\[\]()~`\s]*)([0-9]{1,5})\s*[:\-\—\–.]\s*([^0-9\s].*)$/;
    const matchLeading = normalizedLine.match(leadingNumberRegex);
    if (matchLeading) {
      detectedChapterNum = parseInt(matchLeading[1], 10);
      const sub = matchLeading[2].replace(/^[#=*\-_\[\]()~`\s:–—]+/, '').replace(/[#=*\-_\[\]()~`\s]+$/, '').trim();
      detectedTitle = sub ? `${isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`}: ${sub}` : (isFa ? `فصل ${detectedChapterNum}` : `Chapter ${detectedChapterNum}`);
      headerLineIndex = i;
      break;
    }

    // 5. Short Markdown header: "### The First Encounter"
    const mdHeaderMatch = rawLine.match(/^#{1,4}\s+([^#\n]+)$/);
    if (mdHeaderMatch && mdHeaderMatch[1].trim().length > 1 && mdHeaderMatch[1].trim().length < 80) {
      detectedTitle = mdHeaderMatch[1].trim();
      headerLineIndex = i;
      break;
    }
  }

  // If a header line was found at index 0 or 1, strip it from content body so it is not duplicated
  let finalBody = clean;
  if (headerLineIndex >= 0 && headerLineIndex <= 2) {
    const remainingLines = lines.slice(headerLineIndex + 1);
    finalBody = remainingLines.join('\n').trim();
  }

  const finalNum = detectedChapterNum !== null && detectedChapterNum > 0 ? detectedChapterNum : fallbackIndex;
  const defaultPrefix = isFa ? `فصل ${finalNum}` : isAr ? `الفصل ${finalNum}` : `Chapter ${finalNum}`;
  const finalTitle = detectedTitle || defaultPrefix;

  return {
    title: finalTitle,
    content: finalBody || clean,
    chapterNumber: detectedChapterNum !== null && detectedChapterNum > 0 ? detectedChapterNum : null,
  };
};

/**
 * Clean and extract raw text, chapter title, and chapter number from HTML content.
 * Extracts title and chapter number strictly from inside the HTML document!
 */
export const cleanHtmlToNovelText = (
  rawHtml: string,
  fileName?: string,
  language: Language = 'fa'
): { 
  title: string; 
  content: string; 
  chapterNumber: number | null;
  stats?: { wordCount: number; paragraphCount: number; charCount: number; isComplete: boolean };
} => {
  const isFa = language === 'fa';
  let detectedTitle = '';
  let chapterNumber: number | null = null;
  let cleanText = '';

  if (typeof window !== 'undefined' && typeof DOMParser !== 'undefined') {
    try {
      const parser = new DOMParser();
      const doc = parser.parseFromString(rawHtml, 'text/html');

      // 1. First extract metadata & chapter hints BEFORE stripping elements
      const metaChapter = doc.querySelector('meta[name="chapter"], meta[property="chapter"], meta[name="chapter-number"]')?.getAttribute('content');
      const ogTitle = doc.querySelector('meta[property="og:title"]')?.getAttribute('content');
      const docTitle = doc.querySelector('title')?.textContent?.trim() || '';

      // Check explicit chapter number in meta tag
      if (metaChapter && !isNaN(parseInt(metaChapter, 10))) {
        chapterNumber = parseInt(metaChapter, 10);
      }

      // 2. Try to extract chapter title from inside HTML elements:
      // Check prominent chapter title selectors
      const titleElem =
        doc.querySelector('.chapter-title, #chapter-title, .entry-title, .novel-chapter-title, .reader-chapter, h1.chapter, h2.chapter, h1, h2.chapter-title') ||
        doc.querySelector('h2') ||
        doc.querySelector('.title');

      if (titleElem) {
        const rawTitle = titleElem.textContent?.trim() || '';
        // Clean website brand suffix like " | Webnovel" or " - Free Reading" or "NovelFull"
        const cleanTitle = rawTitle
          .replace(/\s*[|\-—–]\s*(?:Webnovel|ReadNovelFull|NovelFull|Novels|WuxiaWorld|LightNovel|ناول|رمان|Novel Updates|BoxNovel|RoyalRoad|ScribbleHub|MoonQuill).*$/i, '')
          .replace(/^[#=*\-_\[\]()~`\s]+/, '')
          .replace(/[#=*\-_\[\]()~`\s]+$/, '')
          .trim();
        if (cleanTitle.length > 1) {
          detectedTitle = cleanTitle;
        }
      }

      if (!detectedTitle && docTitle) {
        const cleanDocTitle = docTitle
          .replace(/\s*[|\-—–]\s*(?:Webnovel|ReadNovelFull|NovelFull|Novels|WuxiaWorld|LightNovel|ناول|رمان|Novel Updates|BoxNovel|RoyalRoad).*$/i, '')
          .trim();
        if (cleanDocTitle.length > 1) {
          detectedTitle = cleanDocTitle;
        }
      }

      if (!detectedTitle && ogTitle) {
        detectedTitle = ogTitle.replace(/\s*[|\-—–]\s*(?:Webnovel|ReadNovelFull|NovelFull|Novels|WuxiaWorld|LightNovel|ناول|رمان).*$/i, '').trim();
      }

      // 3. Remove non-content elements safely
      const toRemove = doc.querySelectorAll(
        'script, style, noscript, svg, canvas, iframe, nav, header, footer, aside, form, input, button, select, textarea, .ads, .ad, .advertisement, #sidebar, .sidebar, .comments, #comments, .share, .social, .breadcrumb, .breadcrumbs, .pagination, .nav-buttons, .prev-next'
      );
      toRemove.forEach((el) => el.remove());

      // 4. Extract main content container if available
      const contentContainer = doc.querySelector(
        'article, .chapter-content, .entry-content, .novel-content, .reading-content, #chapter-content, #content, .post-content, main, .text-content, .read-content, #read-content'
      );

      const targetRoot = contentContainer || doc.body;

      if (targetRoot) {
        // Collect paragraphs or line-break separated text
        const paragraphs = targetRoot.querySelectorAll('p, div.paragraph, .text-paragraph, li, blockquote');
        if (paragraphs.length >= 2) {
          const lines: string[] = [];
          paragraphs.forEach((p) => {
            const text = p.textContent?.trim();
            if (text && text.length > 0) {
              lines.push(text);
            }
          });
          cleanText = lines.join('\n\n');
        } else {
          // Inner text with breaks
          const clone = targetRoot.cloneNode(true) as HTMLElement;
          clone.querySelectorAll('br').forEach((br) => br.replaceWith('\n'));
          clone.querySelectorAll('p, div, h1, h2, h3, h4, h5, h6, li').forEach((el) => {
            el.insertAdjacentText('afterend', '\n\n');
          });
          cleanText = clone.textContent || '';
        }
      }

      // Check if we can parse chapter number directly from the inside detectedTitle
      if (detectedTitle && chapterNumber === null) {
        const fromTitle = parseChapterFromFileName(detectedTitle, 0, language);
        if (fromTitle.chapterNumber > 0) {
          chapterNumber = fromTitle.chapterNumber;
        }
      }

      // If no title was found from tags, check the first 3 lines of extracted text!
      if (!detectedTitle && cleanText) {
        const textExtract = extractChapterFromTextContent(cleanText, language, 1);
        if (textExtract.chapterNumber !== null) {
          chapterNumber = textExtract.chapterNumber;
          detectedTitle = textExtract.title;
          cleanText = textExtract.content;
        } else if (textExtract.title) {
          detectedTitle = textExtract.title;
        }
      }
    } catch {
      // Fallback to regex below
    }
  }

  // Fallback regex cleaning if DOMParser failed or empty
  if (!cleanText || cleanText.trim().length < 20) {
    if (!detectedTitle) {
      const h1Match = rawHtml.match(/<h[12][^>]*>(.*?)<\/h[12]>/i);
      const titleMatch = rawHtml.match(/<title[^>]*>(.*?)<\/title>/i);
      const ogMatch = rawHtml.match(/<meta[^>]+property=["']og:title["'][^>]+content=["']([\s\S]*?)["']/i);
      const extracted = (h1Match ? h1Match[1] : ogMatch ? ogMatch[1] : titleMatch ? titleMatch[1] : '')
        .replace(/<[^>]+>/g, '')
        .replace(/\s*[|\-—–]\s*(?:Webnovel|ReadNovelFull|NovelFull|Novels|WuxiaWorld|LightNovel|ناول|رمان).*$/i, '')
        .trim();
      if (extracted) {
        detectedTitle = extracted;
      }
    }

    cleanText = rawHtml
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
      .replace(/<noscript\b[^<]*(?:(?!<\/noscript>)<[^<]*)*<\/noscript>/gi, '')
      .replace(/<!--[\s\S]*?-->/g, '')
      .replace(/<(?:p|div|h[1-6]|li|br|tr|blockquote|article|section)[^>]*>/gi, '\n\n')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&amp;/gi, '&')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/[ \t]+/g, ' ')
      .replace(/\n\s*\n\s*\n+/g, '\n\n')
      .trim();
  }

  // Detect chapter number from text start if still null
  if (chapterNumber === null && cleanText) {
    const textSample = (detectedTitle + '\n' + cleanText.slice(0, 800));
    const parsedHeader = extractChapterFromTextContent(textSample, language, 1);
    if (parsedHeader.chapterNumber !== null && parsedHeader.chapterNumber > 0) {
      chapterNumber = parsedHeader.chapterNumber;
      if (!detectedTitle) detectedTitle = parsedHeader.title;
    }
  }

  if (!detectedTitle) {
    detectedTitle = chapterNumber ? (isFa ? `فصل ${chapterNumber}` : `Chapter ${chapterNumber}`) : (isFa ? 'فصل استخراج‌شده' : 'Extracted Chapter');
  }

  const finalContent = cleanText.trim();
  const wordCount = finalContent ? finalContent.split(/\s+/).filter(Boolean).length : 0;
  const paragraphCount = finalContent ? finalContent.split(/\n\s*\n/).filter(p => p.trim().length > 0).length : 0;

  return {
    title: detectedTitle,
    content: finalContent,
    chapterNumber,
    stats: {
      wordCount,
      paragraphCount,
      charCount: finalContent.length,
      isComplete: true,
    },
  };
};

/**
 * Universal content-first chapter extractor (for HTML, TXT, MD, etc.)
 * Strictly prioritizes reading chapter numbers and titles from INSIDE the file content!
 */
export const extractChapterDetailsFromAnyFile = (
  rawContent: string,
  isHtml: boolean,
  language: Language = 'fa',
  fallbackIndex: number = 1,
  fallbackFileName?: string
): {
  title: string;
  content: string;
  chapterNumber: number;
} => {
  const isFa = language === 'fa';

  if (isHtml) {
    const htmlRes = cleanHtmlToNovelText(rawContent, fallbackFileName, language);
    const assignedNum = htmlRes.chapterNumber !== null && htmlRes.chapterNumber > 0
      ? htmlRes.chapterNumber
      : (fallbackFileName ? parseChapterFromFileName(fallbackFileName, fallbackIndex, language).chapterNumber : fallbackIndex);

    const assignedTitle = htmlRes.title || (isFa ? `فصل ${assignedNum}` : `Chapter ${assignedNum}`);
    return {
      title: assignedTitle,
      content: htmlRes.content,
      chapterNumber: assignedNum,
    };
  }

  // TXT / MD content: Extract from inside the text
  const txtRes = extractChapterFromTextContent(rawContent, language, fallbackIndex);
  let assignedNum = txtRes.chapterNumber;

  if (assignedNum === null || assignedNum <= 0) {
    // If not found in first lines, try parsing filename as backup
    if (fallbackFileName) {
      const fromName = parseChapterFromFileName(fallbackFileName, fallbackIndex, language);
      assignedNum = fromName.chapterNumber;
    } else {
      assignedNum = fallbackIndex;
    }
  }

  const assignedTitle = txtRes.title || (isFa ? `فصل ${assignedNum}` : `Chapter ${assignedNum}`);
  return {
    title: assignedTitle,
    content: txtRes.content,
    chapterNumber: assignedNum,
  };
};

/**
 * 100% Free Non-AI Web Translation Engine (Fast, Unlimited, No API Key needed)
 */
export const translateNovelChapterWithFreeEngine = async (
  text: string,
  title: string = '',
  targetLang: string = 'fa'
): Promise<{ title: string; content: string; success: boolean }> => {
  try {
    const res = await fetch('/api/translation/free-engine', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        title,
        targetLang,
        sourceLang: 'auto',
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success && data.content) {
        return {
          title: data.title || title,
          content: data.content,
          success: true,
        };
      }
    }
  } catch (err) {
    console.warn('Free Translation API error:', err);
  }

  // Client-side fallback if server endpoint had issue
  try {
    const [fallbackTitle, fallbackContent] = await Promise.all([
      title ? clientSideTranslateChunk(title, targetLang) : Promise.resolve(title),
      clientSideTranslateChunk(text, targetLang),
    ]);
    if (fallbackContent && fallbackContent.trim().length > 0) {
      return {
        title: fallbackTitle || title,
        content: fallbackContent,
        success: true,
      };
    }
  } catch (e) {
    console.warn('Client-side free translation fallback error:', e);
  }

  return {
    title,
    content: text,
    success: false,
  };
};

/**
 * Client-side direct free web translate fallback (High Speed Parallel Chunking)
 */
async function clientSideTranslateChunk(raw: string, targetLang: string): Promise<string> {
  if (!raw || !raw.trim()) return '';
  const paragraphs = raw.split(/\n\s*\n/);
  const chunks: string[] = [];
  let cur = '';

  for (const p of paragraphs) {
    if ((cur + '\n\n' + p).length > 2500 && cur.length > 0) {
      chunks.push(cur.trim());
      cur = p;
    } else {
      cur = cur ? cur + '\n\n' + p : p;
    }
  }
  if (cur) chunks.push(cur.trim());

  const translateChunk = async (chunk: string): Promise<string> => {
    if (!chunk.trim()) return '';
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(chunk)}`;
      const res = await fetch(url);
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json) && Array.isArray(json[0])) {
          const joined = json[0].map((item: any) => item[0] || '').join('');
          if (joined && joined.trim()) {
            return joined.trim();
          }
        }
      }
    } catch {}
    return chunk;
  };

  const results = await Promise.all(chunks.map((c) => translateChunk(c)));
  return results.join('\n\n');
}

/**
 * Universal Novel Chapter Translator (supports 'free' non-AI engine and 'ai' deep engine)
 */
export const translateNovelChapter = async (
  text: string,
  title: string = '',
  options: {
    engine?: 'free' | 'ai' | 'auto';
    targetLang?: string;
  } = {}
): Promise<{ title: string; content: string; success: boolean; engineUsed?: string }> => {
  const { engine = 'auto', targetLang = 'fa' } = options;

  if (engine === 'free') {
    const res = await translateNovelChapterWithFreeEngine(text, title, targetLang);
    return { ...res, engineUsed: 'free' };
  }

  // Try AI engine first with automatic failover
  const aiRes = await translateNovelChapterWithAI(text, title, targetLang);
  if (aiRes.success) {
    return { ...aiRes, engineUsed: 'ai' };
  }

  // If AI was unsuccessful (e.g. no key or 429), auto fallback to Free Engine
  console.info('[translateNovelChapter] AI returned unsuccessful, falling back to Free Web Engine...');
  const freeRes = await translateNovelChapterWithFreeEngine(text, title, targetLang);
  return { ...freeRes, engineUsed: 'free_fallback' };
};

/**
 * Intelligent AI extraction & translation of novel chapter from HTML
 */
export const translateNovelChapterWithAI = async (
  text: string,
  title: string = '',
  targetLang: string = 'fa'
): Promise<{ title: string; content: string; success: boolean }> => {
  try {
    const userKeys = getStoredSectionAIKeys('translationAI');
    const res = await fetch('/api/gemini/translate-novel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        title,
        targetLang,
        aiKeys: userKeys,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success && data.content) {
        return {
          title: data.title || title,
          content: data.content,
          success: true,
        };
      }
    }
  } catch (err) {
    console.warn('AI Novel translation API error:', err);
  }

  // Fallback to Free Engine if AI failed
  try {
    const freeRes = await translateNovelChapterWithFreeEngine(text, title, targetLang);
    if (freeRes.success) {
      return freeRes;
    }
  } catch {}

  return {
    title,
    content: text,
    success: false,
  };
};

export const extractNovelFromHtmlWithAI = async (
  rawHtml: string,
  options: {
    fileName?: string;
    language?: Language;
    translateTo?: string;
    useTranslation?: boolean;
    translationEngine?: 'free' | 'ai' | 'auto';
  } = {}
): Promise<{ 
  title: string; 
  content: string; 
  chapterNumber: number | null; 
  translated: boolean;
  stats?: { wordCount: number; paragraphCount: number; charCount: number; isComplete: boolean };
}> => {
  const { fileName = '', language = 'fa', translateTo, useTranslation = false, translationEngine = 'free' } = options;
  const isFa = language === 'fa';
  const targetLanguage = translateTo || (isFa ? 'fa' : 'en');

  // 1. Initial client-side cleanup to avoid sending enormous 10MB raw HTML if not needed
  const clientParsed = cleanHtmlToNovelText(rawHtml, fileName, language);

  try {
    const userKeys = getStoredSectionAIKeys('translationAI');
    const res = await fetch('/api/gemini/extract-html-novel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        htmlContent: rawHtml.length > 250000 ? clientParsed.content : rawHtml,
        fileName,
        language,
        translateTo: targetLanguage,
        useTranslation,
        translationEngine,
        aiKeys: userKeys,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.success && data.content) {
        let finalContent = data.content;
        let finalTitle = data.title || clientParsed.title;
        let isTranslated = Boolean(data.translated);

        // If translation was requested but server couldn't translate in single pass, trigger dedicated translation
        if (useTranslation && !isTranslated) {
          const trans = await translateNovelChapter(finalContent, finalTitle, { engine: translationEngine, targetLang: targetLanguage });
          if (trans.success && trans.content) {
            finalContent = trans.content;
            finalTitle = trans.title || finalTitle;
            isTranslated = true;
          }
        }

        const wordCount = finalContent ? finalContent.split(/\s+/).filter(Boolean).length : 0;
        const paragraphCount = finalContent ? finalContent.split(/\n\s*\n/).filter((p: string) => p.trim().length > 0).length : 0;

        return {
          title: finalTitle,
          content: finalContent,
          chapterNumber: typeof data.chapterNumber === 'number' && data.chapterNumber > 0 ? data.chapterNumber : clientParsed.chapterNumber,
          translated: isTranslated,
          stats: {
            wordCount,
            paragraphCount,
            charCount: finalContent.length,
            isComplete: true,
          },
        };
      }
    }
  } catch (err) {
    console.warn('AI HTML extraction API failed, falling back to client-side DOM parser:', err);
  }

  let fallbackContent = clientParsed.content;
  let fallbackTitle = clientParsed.title;
  let fallbackTranslated = false;

  if (useTranslation) {
    const trans = await translateNovelChapter(fallbackContent, fallbackTitle, { engine: translationEngine, targetLang: targetLanguage });
    if (trans.success && trans.content) {
      fallbackContent = trans.content;
      fallbackTitle = trans.title || fallbackTitle;
      fallbackTranslated = true;
    }
  }

  const fallbackWordCount = fallbackContent ? fallbackContent.split(/\s+/).filter(Boolean).length : 0;
  const fallbackParaCount = fallbackContent ? fallbackContent.split(/\n\s*\n/).filter((p: string) => p.trim().length > 0).length : 0;

  // Graceful fallback to client-side parsed data
  return {
    title: fallbackTitle,
    content: fallbackContent,
    chapterNumber: clientParsed.chapterNumber,
    translated: fallbackTranslated,
    stats: {
      wordCount: fallbackWordCount,
      paragraphCount: fallbackParaCount,
      charCount: fallbackContent.length,
      isComplete: true,
    },
  };
};

/**
 * Intelligently parse chapter number and title from a filename or header text
 */
export const parseChapterFromFileName = (rawFileName: string, fallbackIndex: number, language: Language = 'fa'): { chapterNumber: number; title: string } => {
  // Remove file extension
  const withoutExt = rawFileName.replace(/\.[^/.]+$/, '').trim();
  const normalized = normalizeDigits(withoutExt);

  let chapterNum: number | null = null;
  let subTitle = '';

  // 1. Check Asian notation: 第50章, 第50话, 第50回, 50화, 50장
  const asianRegex = /(?:第\s*([0-9]{1,5})\s*(?:章|话|回)|([0-9]{1,5})\s*(?:화|장|章|话|回))(.*)/;
  const matchAsian = normalized.match(asianRegex);
  if (matchAsian) {
    chapterNum = parseInt(matchAsian[1] || matchAsian[2], 10);
    subTitle = (matchAsian[3] || '').replace(/^[\s_.:-]+/, '').trim();
  }

  // 2. Check explicit keyword with numbers: فصل 50, چپتر 50, Chapter 50, Ch. 50, Ch 50, Part 50, Episode 50, Vol 2 Ch 50
  if (chapterNum === null) {
    const keywordRegex = /(?:^|[\s_.-])(?:فصل|چپتر|قسمت|بخش|الفصل|باب|chapter|ch\.|ch|part|episode|ep|vol|c)[\s_.-]*([0-9]{1,5})(.*)/i;
    const matchKeyword = normalized.match(keywordRegex);

    if (matchKeyword) {
      chapterNum = parseInt(matchKeyword[1], 10);
      subTitle = matchKeyword[2].replace(/^[\s_.:-]+/, '').trim();
    }
  }

  // 3. Check keyword with word numbers: فصل اول, Chapter first, الفصل الثاني, فصل پنجاه
  if (chapterNum === null) {
    for (const [word, num] of Object.entries(WORD_NUMBERS)) {
      const wordRegex = new RegExp(`(?:^|[\\s_.-])(?:فصل|چپتر|قسمت|الفصل|chapter|ch)[\\s_.-]+${word}(.*)`, 'i');
      const matchWord = normalized.match(wordRegex);
      if (matchWord) {
        chapterNum = num;
        subTitle = matchWord[1].replace(/^[\s_.:-]+/, '').trim();
        break;
      }
    }
  }

  // 4. Check leading digits: "50 - Introduction", "05_the_battle", "50. Beginning"
  if (chapterNum === null) {
    const leadingDigitsRegex = /^([0-9]{1,5})[\s_.:-]+(.*)/;
    const matchLeading = normalized.match(leadingDigitsRegex);
    if (matchLeading) {
      chapterNum = parseInt(matchLeading[1], 10);
      subTitle = matchLeading[2].trim();
    }
  }

  // 5. Check trailing digits: "Solo_Leveling_50", "Novel_Ch_50"
  if (chapterNum === null) {
    const trailingDigitsRegex = /(.*)[\s_.-]+([0-9]{1,5})$/;
    const matchTrailing = normalized.match(trailingDigitsRegex);
    if (matchTrailing) {
      chapterNum = parseInt(matchTrailing[2], 10);
      subTitle = matchTrailing[1].trim();
    }
  }

  // 6. Check any isolated digits in filename
  if (chapterNum === null) {
    const anyDigitRegex = /(?:^|[^0-9])([0-9]{1,5})(?:[^0-9]|$)/;
    const matchAny = normalized.match(anyDigitRegex);
    if (matchAny) {
      chapterNum = parseInt(matchAny[1], 10);
    }
  }

  // Fallback if no number detected
  const finalChapterNum = chapterNum !== null && !isNaN(chapterNum) && chapterNum > 0
    ? chapterNum
    : fallbackIndex;

  // Format clean human title
  let finalTitle = '';
  const isFa = language === 'fa';
  const isAr = language === 'ar';

  const prefix = isFa ? `فصل ${finalChapterNum}` : isAr ? `الفصل ${finalChapterNum}` : `Chapter ${finalChapterNum}`;

  if (subTitle && subTitle.length > 1 && !/^[0-9_\s-]+$/.test(subTitle)) {
    const cleanSub = subTitle.replace(/[_-]/g, ' ').trim();
    finalTitle = `${prefix}: ${cleanSub}`;
  } else {
    // If the filename has useful text without the number
    const cleanRaw = withoutExt.replace(/[_-]/g, ' ').replace(/\s+/g, ' ').trim();
    if (cleanRaw.length > 2 && !/^\d+$/.test(cleanRaw)) {
      finalTitle = cleanRaw.includes(String(finalChapterNum)) ? cleanRaw : `${prefix}: ${cleanRaw}`;
    } else {
      finalTitle = prefix;
    }
  }

  return {
    chapterNumber: finalChapterNum,
    title: finalTitle,
  };
};

/**
 * Naturally sort an array of parsed files so that ch1, ch2, ch10, ch20 are in correct mathematical order
 */
export const sortParsedFiles = (files: ParsedFileInfo[]): ParsedFileInfo[] => {
  return [...files].sort((a, b) => {
    const numA = a.detectedChapterNumber ?? 999999;
    const numB = b.detectedChapterNumber ?? 999999;
    if (numA !== numB) {
      return numA - numB;
    }
    return a.fileName.localeCompare(b.fileName, undefined, { numeric: true, sensitivity: 'base' });
  });
};

/**
 * Split a single long novel text file into multiple chapters based on headings
 */
export const autoSplitSingleFileChapters = (
  textContent: string, 
  defaultPrice: number = 2,
  language: Language = 'fa',
  existingOffset: number = 0
): WebNovelChapter[] => {
  const isFa = language === 'fa';
  // Regex to detect chapter headers in Persian, Arabic, or English
  // Matches: "فصل 1", "فصل اول", "Chapter 1", "## الفصل الأول", "### Chapter 5", "--- فصل ۲ ---", "[فصل ۳]", "بخش ۴"
  const chapterHeaderRegex = /(?:^|\n)(?:[#=*_\-\[\]()~`]+\s*)*(?:فصل|چپتر|قسمت|بخش|الفصل|Chapter|Ch\.|Episode|Part)\s*(?:[۰-۹0-9]+|[a-zA-Z\u0600-\u06FF]+)?(?:\s*[:\-\—\–]\s*[^\n]+|\s*[^\n]*)?(?:\n|$)/gi;

  const matches = [...textContent.matchAll(chapterHeaderRegex)];

  if (matches.length <= 1) {
    const title = isFa ? `فصل ${existingOffset + 1}: متن کامل` : `Chapter ${existingOffset + 1}: Full Content`;
    return [
      {
        id: `ch-1-${Date.now()}`,
        chapterNumber: existingOffset + 1,
        title,
        price: defaultPrice,
        content: textContent.trim(),
      }
    ];
  }

  const result: WebNovelChapter[] = [];

  for (let i = 0; i < matches.length; i++) {
    const start = matches[i].index || 0;
    const end = i < matches.length - 1 ? (matches[i + 1].index || textContent.length) : textContent.length;
    const fullBlock = textContent.slice(start, end).trim();
    const lines = fullBlock.split('\n');
    
    // The first line is the chapter header
    const rawHeader = lines[0].replace(/^[#=*\-_\[\]()~`\s]+/, '').replace(/[#=*\-_\[\]()~`\s]+$/, '').trim();
    const bodyContent = lines.slice(1).join('\n').trim();

    const assignedNumber = existingOffset + i + 1;
    const parsed = parseChapterFromFileName(rawHeader || `Chapter ${assignedNumber}`, assignedNumber, language);

    result.push({
      id: `ch-${assignedNumber}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      chapterNumber: assignedNumber,
      title: rawHeader || parsed.title,
      price: defaultPrice,
      content: bodyContent || fullBlock,
    });
  }

  return result;
};

export type SplitMode = 'auto' | 'delimiter' | 'word_count' | 'single';

/**
 * Super-flexible text splitter for pasted novel content
 */
export const splitPastedTextIntoChapters = (
  rawText: string,
  mode: SplitMode = 'auto',
  options: {
    delimiter?: string;
    wordsPerChapter?: number;
    language?: Language;
    existingOffset?: number;
    defaultPrice?: number;
  } = {}
): ExtractedChapterItem[] => {
  const clean = rawText.trim();
  if (!clean) return [];

  const {
    delimiter = '===',
    wordsPerChapter = 1000,
    language = 'fa',
    existingOffset = 0,
    defaultPrice = 2,
  } = options;

  const isFa = language === 'fa';

  if (mode === 'single') {
    const num = existingOffset + 1;
    return [{
      id: `custom-ch-${Date.now()}-0`,
      chapterNumber: num,
      title: isFa ? `فصل ${num}: متن اصلی` : `Chapter ${num}`,
      content: clean,
    }];
  }

  if (mode === 'delimiter') {
    const safeDelim = delimiter.trim() || '===';
    const parts = clean.split(new RegExp(`(?:^|\\n)\\s*${safeDelim.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*(?:\\n|$)`, 'g'))
      .map(p => p.trim())
      .filter(Boolean);

    if (parts.length <= 1) {
      // Try line-based delimiter split
      const fallbackParts = clean.split(safeDelim).map(p => p.trim()).filter(Boolean);
      if (fallbackParts.length > 1) {
        return fallbackParts.map((part, idx) => {
          const num = existingOffset + idx + 1;
          const firstLine = part.split('\n')[0].trim();
          const title = firstLine.length > 1 && firstLine.length < 60
            ? firstLine
            : (isFa ? `فصل ${num}` : `Chapter ${num}`);
          const content = firstLine === title ? part.split('\n').slice(1).join('\n').trim() : part;
          return {
            id: `custom-ch-${Date.now()}-${idx}`,
            chapterNumber: num,
            title,
            content: content || part,
          };
        });
      }
    } else {
      return parts.map((part, idx) => {
        const num = existingOffset + idx + 1;
        const firstLine = part.split('\n')[0].trim();
        const title = firstLine.length > 1 && firstLine.length < 60
          ? firstLine
          : (isFa ? `فصل ${num}` : `Chapter ${num}`);
        const content = firstLine === title ? part.split('\n').slice(1).join('\n').trim() : part;
        return {
          id: `custom-ch-${Date.now()}-${idx}`,
          chapterNumber: num,
          title,
          content: content || part,
        };
      });
    }
  }

  if (mode === 'word_count') {
    const words = clean.split(/\s+/);
    const targetSize = Math.max(100, wordsPerChapter || 1000);
    const result: ExtractedChapterItem[] = [];

    let currentWords: string[] = [];
    let chIdx = 0;

    for (let i = 0; i < words.length; i++) {
      currentWords.push(words[i]);
      if (currentWords.length >= targetSize || i === words.length - 1) {
        const num = existingOffset + chIdx + 1;
        result.push({
          id: `custom-ch-${Date.now()}-${chIdx}`,
          chapterNumber: num,
          title: isFa ? `فصل ${num}` : `Chapter ${num}`,
          content: currentWords.join(' '),
        });
        currentWords = [];
        chIdx++;
      }
    }
    return result;
  }

  // Default 'auto' mode
  const autoList = autoSplitSingleFileChapters(clean, defaultPrice, language, existingOffset);
  return autoList.map((ch, idx) => ({
    id: ch.id,
    chapterNumber: ch.chapterNumber || existingOffset + idx + 1,
    title: ch.title,
    content: ch.content,
  }));
};

export interface ExtractedChapterItem {
  id?: string;
  title: string;
  content: string;
  chapterNumber: number;
  sourceFileName?: string;
  isHtml?: boolean;
}

export interface ZipExtractionResult {
  chapters: ExtractedChapterItem[];
  detectedNovelTitle: string;
  totalFilesFound: number;
  extractedTextCount: number;
  zipName: string;
  htmlCount: number;
}

/**
 * Robustly decode ArrayBuffer or Uint8Array to string supporting UTF-8 and Persian/Arabic text
 */
export const decodeTextContent = (buffer: ArrayBuffer | Uint8Array): string => {
  try {
    const decoder = new TextDecoder('utf-8', { fatal: false });
    return decoder.decode(buffer);
  } catch {
    // Fallback if TextDecoder not available
    const uint8 = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < uint8.length; i++) {
      binary += String.fromCharCode(uint8[i]);
    }
    try {
      return decodeURIComponent(escape(binary));
    } catch {
      return binary;
    }
  }
};

/**
 * Unpacks a ZIP file, extracts chapter text and HTML files, detects chapter ordering, and sorts them naturally
 */
export const extractChaptersFromZip = async (
  zipFile: File,
  language: Language = 'fa',
  existingChaptersCount: number = 0,
  defaultPrice: number = 2,
  options: {
    useAiHtmlExtraction?: boolean;
    useTranslation?: boolean;
    translationEngine?: 'free' | 'ai' | 'auto';
    translateTo?: string;
    onProgress?: (text: string) => void;
  } = {}
): Promise<ZipExtractionResult> => {
  const isFa = language === 'fa';
  const translationEngine = options.translationEngine || 'free';
  const zip = await JSZip.loadAsync(zipFile);

  const cleanZipName = zipFile.name.replace(/\.[^/.]+$/, '').trim();
  
  // Try to derive a clean novel title from the ZIP file's name
  let detectedTitle = cleanZipName
    .replace(/(?:فصل|چپتر|قسمت|chapter|ch|part|vol|volume)[\s_.-]*[0-9]+.*$/i, '')
    .replace(/[_-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!detectedTitle || detectedTitle.length < 2) {
    detectedTitle = cleanZipName.replace(/[_-]/g, ' ').trim();
  }

  const rawEntries: { fileName: string; fullPath: string; isHtml: boolean; bufferPromise: () => Promise<ArrayBuffer> }[] = [];

  zip.forEach((relativePath, entry) => {
    // Skip directories and OS junk files
    if (entry.dir) return;
    if (relativePath.includes('__MACOSX/') || relativePath.startsWith('.') || relativePath.includes('/.')) return;
    if (relativePath.endsWith('.DS_Store') || relativePath.endsWith('Thumbs.db')) return;

    // Filter text/chapter friendly extensions including HTML
    const ext = relativePath.split('.').pop()?.toLowerCase() || '';
    const isHtml = ['html', 'htm', 'xhtml'].includes(ext);
    const isTextExt = ['txt', 'md', 'text', 'json', 'rtf', 'csv', 'html', 'htm', 'xhtml'].includes(ext);

    // If extension is not specified or looks like a text/html file
    if (isTextExt || !ext || ext.length > 5) {
      const baseName = relativePath.split('/').pop() || relativePath;
      rawEntries.push({
        fileName: baseName,
        fullPath: relativePath,
        isHtml,
        bufferPromise: () => entry.async('arraybuffer'),
      });
    }
  });

  if (rawEntries.length === 0) {
    throw new Error(isFa ? 'هیچ فایل متنی یا HTML (TXT, HTML, MD) درون این فایل ZIP یافت نشد.' : 'No text or HTML chapter files found in this ZIP archive.');
  }

  const htmlCount = rawEntries.filter((e) => e.isHtml).length;

  // If there is only ONE single file in the ZIP
  if (rawEntries.length === 1) {
    const singleEntry = rawEntries[0];
    const buffer = await singleEntry.bufferPromise();
    const rawContent = decodeTextContent(buffer);

    let textContent = rawContent;
    let singleDetectedTitle = '';

    if (singleEntry.isHtml) {
      const cleaned = cleanHtmlToNovelText(rawContent, singleEntry.fileName, language);
      textContent = cleaned.content;
      singleDetectedTitle = cleaned.title;
    }

    const splitChapters = autoSplitSingleFileChapters(textContent, defaultPrice, language, existingChaptersCount);
    
    const chapters: ExtractedChapterItem[] = splitChapters.map((ch, idx) => ({
      id: ch.id,
      title: singleDetectedTitle || ch.title,
      content: ch.content,
      chapterNumber: existingChaptersCount + idx + 1,
      sourceFileName: singleEntry.fileName,
      isHtml: singleEntry.isHtml,
    }));

    return {
      chapters,
      detectedNovelTitle: detectedTitle,
      totalFilesFound: 1,
      extractedTextCount: 1,
      zipName: zipFile.name,
      htmlCount,
    };
  }

  // Multi-file ZIP archive: Read and extract chapter numbers & titles directly from INSIDE file contents
  const loadedEntries: {
    fileName: string;
    fullPath: string;
    isHtml: boolean;
    rawText: string;
    detectedChapterNumber: number | null;
    detectedTitle: string;
    content: string;
  }[] = [];

  for (let i = 0; i < rawEntries.length; i++) {
    const entry = rawEntries[i];
    const buffer = await entry.bufferPromise();
    const rawText = decodeTextContent(buffer).trim();
    if (!rawText) continue;

    const extracted = extractChapterDetailsFromAnyFile(
      rawText,
      entry.isHtml,
      language,
      existingChaptersCount + loadedEntries.length + 1,
      entry.fileName
    );

    loadedEntries.push({
      fileName: entry.fileName,
      fullPath: entry.fullPath,
      isHtml: entry.isHtml,
      rawText,
      detectedChapterNumber: extracted.chapterNumber,
      detectedTitle: extracted.title,
      content: extracted.content,
    });
  }

  // Naturally sort files by mathematical chapter number extracted from file content
  loadedEntries.sort((a, b) => {
    const numA = a.detectedChapterNumber ?? 999999;
    const numB = b.detectedChapterNumber ?? 999999;
    if (numA !== numB) {
      return numA - numB;
    }
    return a.fileName.localeCompare(b.fileName, undefined, { numeric: true, sensitivity: 'base' });
  });

  // Extract chapters in sorted order
  const finalChapters: ExtractedChapterItem[] = loadedEntries.map((item, idx) => {
    const assignedNum = item.detectedChapterNumber || (existingChaptersCount + idx + 1);
    const cleanTitle = item.detectedTitle || (isFa ? `فصل ${assignedNum}` : `Chapter ${assignedNum}`);

    return {
      id: `custom-ch-${Date.now()}-${idx}-${Math.random().toString(36).substring(2, 6)}`,
      title: cleanTitle,
      content: item.content,
      chapterNumber: assignedNum,
      sourceFileName: item.fileName,
      isHtml: item.isHtml,
    };
  });

  if (finalChapters.length === 0) {
    throw new Error(isFa ? 'فایل‌های متنی یا HTML درون ZIP خالی بودند.' : 'Files in the ZIP archive were empty.');
  }

  return {
    chapters: finalChapters,
    detectedNovelTitle: detectedTitle,
    totalFilesFound: rawEntries.length,
    extractedTextCount: finalChapters.length,
    zipName: zipFile.name,
    htmlCount,
  };
};
