import { WebNovel, WebNovelChapter, Language } from '../types';
import { translateNovelChapter } from './novelParser';
import { safeStorage } from './safeStorage';
import { getCustomWebNovels, saveCustomWebNovels } from './rewardWallet';

export interface BackgroundTranslationJob {
  id: string;
  novelId: string;
  novelTitle: string;
  author?: string;
  genre?: string;
  synopsis?: string;
  coverGradient?: string;
  price: number;
  pricePerChapter?: number;
  isPriceLocked?: boolean;
  targetLang: 'fa' | 'ar' | 'en';
  engine: 'free' | 'ai';
  status: 'running' | 'paused' | 'completed' | 'cancelled' | 'error' | 'queued';
  totalChapters: number;
  completedChapters: number;
  currentChapterIndex: number;
  currentChapterTitle: string;
  currentProgressPercent?: number;
  isServerJob?: boolean;
  createdAt: number;
  updatedAt: number;
  error?: string;
  chapters: {
    id: string;
    title: string;
    content: string;
    chapterNumber: number;
    sourceFileName?: string;
    isTranslated?: boolean;
  }[];
}

const JOBS_STORAGE_KEY = 'reward_background_novel_translation_jobs_v2';

class BackgroundNovelTranslationManager {
  private jobs: Map<string, BackgroundTranslationJob> = new Map();
  private listeners: Set<(jobs: BackgroundTranslationJob[]) => void> = new Set();
  private abortControllers: Map<string, AbortController> = new Map();
  private activeWorkers: Map<string, boolean> = new Map();
  private pollInterval: any = null;

  constructor() {
    this.loadPersistedJobs();
    this.startServerSyncPolling();
  }

  private loadPersistedJobs() {
    try {
      const raw = safeStorage.getItem(JOBS_STORAGE_KEY);
      if (raw) {
        const list: BackgroundTranslationJob[] = JSON.parse(raw);
        if (Array.isArray(list)) {
          list.forEach((j) => {
            if (!j.isServerJob && j.status === 'running') {
              j.status = 'paused';
            }
            this.jobs.set(j.id, j);
          });
        }
      }
    } catch (e) {
      console.warn('Failed to load background translation jobs:', e);
    }
  }

  private persistJobs() {
    try {
      const list = Array.from(this.jobs.values());
      safeStorage.setItem(JOBS_STORAGE_KEY, JSON.stringify(list));
    } catch {}
    this.notifyListeners();
  }

  public subscribe(callback: (jobs: BackgroundTranslationJob[]) => void): () => void {
    this.listeners.add(callback);
    callback(this.getAllJobs());
    return () => {
      this.listeners.delete(callback);
    };
  }

  private notifyListeners() {
    const list = this.getAllJobs();
    this.listeners.forEach((cb) => {
      try {
        cb(list);
      } catch (err) {
        console.error('Error in job listener callback:', err);
      }
    });
  }

  public getAllJobs(): BackgroundTranslationJob[] {
    return Array.from(this.jobs.values()).sort((a, b) => b.createdAt - a.createdAt);
  }

  public getActiveJobs(): BackgroundTranslationJob[] {
    return this.getAllJobs().filter(
      (j) => j.status === 'running' || j.status === 'paused' || j.status === 'queued'
    );
  }

  public getJob(id: string): BackgroundTranslationJob | undefined {
    return this.jobs.get(id);
  }

  /**
   * Start polling server for background jobs
   */
  public startServerSyncPolling() {
    if (this.pollInterval) return;
    this.syncWithServerJobs();
    this.pollInterval = setInterval(() => {
      this.syncWithServerJobs();
    }, 3000);

    if (typeof window !== 'undefined') {
      window.addEventListener('focus', () => {
        this.syncWithServerJobs();
      });
    }
  }

  /**
   * Sync active server jobs into client store
   */
  public async syncWithServerJobs() {
    try {
      const res = await fetch('/api/translation/server-jobs');
      if (!res.ok) return;
      const data = await res.json();
      if (data.success && Array.isArray(data.jobs)) {
        let changed = false;
        data.jobs.forEach((serverJob: any) => {
          const clientJob: BackgroundTranslationJob = {
            id: serverJob.id,
            novelId: serverJob.novelId,
            novelTitle: serverJob.novelTitle,
            author: serverJob.author,
            genre: serverJob.genre,
            synopsis: serverJob.synopsis,
            coverGradient: serverJob.coverGradient,
            price: serverJob.price,
            pricePerChapter: serverJob.pricePerChapter,
            isPriceLocked: serverJob.isPriceLocked,
            targetLang: serverJob.targetLang,
            engine: serverJob.engine,
            status: serverJob.status,
            totalChapters: serverJob.totalChapters,
            completedChapters: serverJob.completedChapters,
            currentChapterIndex: serverJob.currentChapterIndex,
            currentChapterTitle: serverJob.currentChapterTitle,
            currentProgressPercent: serverJob.currentProgressPercent,
            isServerJob: true,
            createdAt: serverJob.createdAt,
            updatedAt: serverJob.updatedAt,
            error: serverJob.error,
            chapters: serverJob.chapters || [],
          };

          const prev = this.jobs.get(serverJob.id);
          if (!prev || prev.updatedAt !== serverJob.updatedAt || prev.completedChapters !== serverJob.completedChapters || prev.status !== serverJob.status) {
            this.jobs.set(serverJob.id, clientJob);
            this.syncNovelToStorage(clientJob);
            changed = true;
          }
        });

        if (changed) {
          this.persistJobs();
        }
      }
    } catch {}
  }

  /**
   * Start a translation job on the server (True background persistence across page closes)
   */
  public async startServerJob(params: {
    novelId?: string;
    novelTitle: string;
    author?: string;
    genre?: string;
    synopsis?: string;
    coverGradient?: string;
    price?: number;
    pricePerChapter?: number;
    isPriceLocked?: boolean;
    chapters: {
      id?: string;
      title: string;
      content: string;
      chapterNumber: number;
      sourceFileName?: string;
      isTranslated?: boolean;
    }[];
    targetLang: 'fa' | 'ar' | 'en';
    engine: 'free' | 'ai';
  }): Promise<string> {
    const novelId = params.novelId || `custom-novel-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const tempJobId = `srv-job-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    const normalizedChapters = params.chapters.map((ch, idx) => ({
      id: ch.id || `ch-${novelId}-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`,
      title: ch.title || `فصل ${idx + 1}`,
      content: ch.content,
      chapterNumber: ch.chapterNumber || idx + 1,
      sourceFileName: ch.sourceFileName,
      isTranslated: Boolean(ch.isTranslated),
    }));

    const optimisticJob: BackgroundTranslationJob = {
      id: tempJobId,
      novelId,
      novelTitle: params.novelTitle,
      author: params.author || 'ناشناس',
      genre: params.genre || 'عمومی',
      synopsis: params.synopsis || 'رمان در حال ترجمه در پس‌زمینه سرور...',
      coverGradient: params.coverGradient || 'from-blue-600 via-indigo-700 to-purple-900',
      price: params.price ?? 2,
      pricePerChapter: params.pricePerChapter ?? 2,
      isPriceLocked: params.isPriceLocked ?? true,
      targetLang: params.targetLang,
      engine: params.engine,
      status: 'running',
      totalChapters: normalizedChapters.length,
      completedChapters: normalizedChapters.filter((c) => c.isTranslated).length,
      currentChapterIndex: 0,
      currentChapterTitle: normalizedChapters[0]?.title || '',
      isServerJob: true,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      chapters: normalizedChapters,
    };

    this.jobs.set(tempJobId, optimisticJob);
    this.persistJobs();
    this.syncNovelToStorage(optimisticJob);

    try {
      const res = await fetch('/api/translation/server-jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          novelId,
          novelTitle: params.novelTitle,
          author: params.author,
          genre: params.genre,
          synopsis: params.synopsis,
          coverGradient: params.coverGradient,
          price: params.price,
          pricePerChapter: params.pricePerChapter,
          isPriceLocked: params.isPriceLocked,
          targetLang: params.targetLang,
          engine: params.engine,
          chapters: normalizedChapters,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.job) {
          this.jobs.delete(tempJobId);
          this.jobs.set(data.job.id, {
            ...data.job,
            isServerJob: true,
          });
          this.persistJobs();
          return data.job.id;
        }
      }
    } catch (e) {
      console.warn('Failed to start server translation job, falling back to local runner:', e);
      optimisticJob.isServerJob = false;
      this.runJob(tempJobId);
    }

    return tempJobId;
  }

  /**
   * Start or queue a new client-side background novel translation job
   */
  public startNewJob(params: {
    novelId?: string;
    novelTitle: string;
    author?: string;
    genre?: string;
    synopsis?: string;
    coverGradient?: string;
    price?: number;
    pricePerChapter?: number;
    isPriceLocked?: boolean;
    chapters: {
      id?: string;
      title: string;
      content: string;
      chapterNumber: number;
      sourceFileName?: string;
      isTranslated?: boolean;
    }[];
    targetLang: 'fa' | 'ar' | 'en';
    engine: 'free' | 'ai';
    runOnServer?: boolean;
  }): string {
    if (params.runOnServer) {
      this.startServerJob(params);
      return `srv-job-${Date.now()}`;
    }

    const novelId = params.novelId || `custom-novel-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const jobId = `job-trans-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

    const normalizedChapters = params.chapters.map((ch, idx) => ({
      id: ch.id || `ch-${novelId}-${idx + 1}-${Math.random().toString(36).substring(2, 6)}`,
      title: ch.title || `فصل ${idx + 1}`,
      content: ch.content,
      chapterNumber: ch.chapterNumber || (idx + 1),
      sourceFileName: ch.sourceFileName,
      isTranslated: Boolean(ch.isTranslated),
    }));

    const job: BackgroundTranslationJob = {
      id: jobId,
      novelId,
      novelTitle: params.novelTitle,
      author: params.author || 'ناشناس',
      genre: params.genre || 'سیستم و تناسخ',
      synopsis: params.synopsis || 'رمان در حال ترجمه و بارگذاری خودکار...',
      coverGradient: params.coverGradient || 'from-blue-600 via-indigo-700 to-purple-900',
      price: params.price ?? 2,
      pricePerChapter: params.pricePerChapter ?? 2,
      isPriceLocked: params.isPriceLocked ?? true,
      targetLang: params.targetLang,
      engine: params.engine,
      status: 'running',
      totalChapters: normalizedChapters.length,
      completedChapters: normalizedChapters.filter((c) => c.isTranslated).length,
      currentChapterIndex: 0,
      currentChapterTitle: normalizedChapters[0]?.title || '',
      isServerJob: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      chapters: normalizedChapters,
    };

    this.jobs.set(jobId, job);
    this.persistJobs();
    this.syncNovelToStorage(job);

    this.runJob(jobId);
    return jobId;
  }

  /**
   * Offload an existing or active job to the server for continuous processing
   */
  public async offloadToServer(jobId: string): Promise<boolean> {
    const job = this.jobs.get(jobId);
    if (!job) return false;

    // Pause local worker
    this.pauseJob(jobId);

    try {
      const res = await fetch('/api/translation/server-jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          novelId: job.novelId,
          novelTitle: job.novelTitle,
          author: job.author,
          genre: job.genre,
          synopsis: job.synopsis,
          coverGradient: job.coverGradient,
          price: job.price,
          pricePerChapter: job.pricePerChapter,
          isPriceLocked: job.isPriceLocked,
          targetLang: job.targetLang,
          engine: job.engine,
          chapters: job.chapters,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.job) {
          this.jobs.delete(jobId);
          this.jobs.set(data.job.id, {
            ...data.job,
            isServerJob: true,
          });
          this.persistJobs();
          return true;
        }
      }
    } catch (e) {
      console.warn('Failed to offload job to server:', e);
    }
    return false;
  }

  /**
   * Progressive sync of translated chapters into customNovels in localStorage and server
   */
  public syncNovelToStorage(job: BackgroundTranslationJob) {
    try {
      const existing = getCustomWebNovels();
      const existingIdx = existing.findIndex((n) => n.id === job.novelId);

      const novelObj: WebNovel = {
        id: job.novelId,
        title: job.novelTitle,
        author: job.author,
        genre: job.genre || 'عمومی',
        synopsis: job.synopsis || '',
        coverGradient: job.coverGradient,
        price: job.price,
        pricePerChapter: job.pricePerChapter,
        isPriceLocked: job.isPriceLocked,
        chapters: job.chapters.map((c) => ({
          id: c.id,
          title: c.title,
          content: c.content,
          chapterNumber: c.chapterNumber,
          price: job.pricePerChapter || 2,
        })),
        isDefault: false,
        uploadedAt: new Date().toISOString(),
      };

      let updatedList: WebNovel[];
      if (existingIdx >= 0) {
        updatedList = [...existing];
        updatedList[existingIdx] = novelObj;
      } else {
        updatedList = [novelObj, ...existing];
      }

      saveCustomWebNovels(updatedList);

      try {
        window.dispatchEvent(new CustomEvent('customNovelsUpdated', { detail: { novels: updatedList } }));
      } catch {}
    } catch (e) {
      console.warn('Error syncing novel progress to storage:', e);
    }
  }

  /**
   * Run translation loop with parallel workers for maximum speed (Client worker)
   */
  private async runJob(jobId: string) {
    const job = this.jobs.get(jobId);
    if (!job || job.status !== 'running' || job.isServerJob) return;
    if (this.activeWorkers.get(jobId)) return;

    this.activeWorkers.set(jobId, true);
    const abortCtrl = new AbortController();
    this.abortControllers.set(jobId, abortCtrl);

    const concurrency = job.engine === 'free' ? 3 : 2;
    const chapters = job.chapters;
    let nextIdx = 0;

    for (let i = 0; i < chapters.length; i++) {
      if (!chapters[i].isTranslated) {
        nextIdx = i;
        break;
      }
    }

    const worker = async () => {
      while (nextIdx < chapters.length) {
        const currentJob = this.jobs.get(jobId);
        if (!currentJob || currentJob.status !== 'running' || abortCtrl.signal.aborted) {
          break;
        }

        const idx = nextIdx++;
        const ch = chapters[idx];
        if (!ch) continue;
        if (ch.isTranslated) continue;

        currentJob.currentChapterIndex = idx;
        currentJob.currentChapterTitle = ch.title;
        currentJob.updatedAt = Date.now();
        this.persistJobs();

        try {
          const res = await translateNovelChapter(ch.content, ch.title, {
            engine: currentJob.engine,
            targetLang: currentJob.targetLang,
          });

          if (res.success && res.content) {
            ch.content = res.content;
            if (res.title) {
              ch.title = res.title;
            }
            ch.isTranslated = true;
          }

          currentJob.completedChapters = chapters.filter((c) => c.isTranslated).length;
          currentJob.currentProgressPercent = Math.min(
            100,
            Math.round((currentJob.completedChapters / currentJob.totalChapters) * 100)
          );
          currentJob.updatedAt = Date.now();

          this.syncNovelToStorage(currentJob);
          this.persistJobs();
        } catch (err: any) {
          console.warn(`[BackgroundTranslator] Error translating chapter ${idx + 1}:`, err);
        }
      }
    };

    try {
      const workers = Array.from({ length: Math.min(concurrency, chapters.length) }, () => worker());
      await Promise.all(workers);

      const finalJob = this.jobs.get(jobId);
      if (finalJob && finalJob.status === 'running') {
        const allDone = finalJob.chapters.every((c) => c.isTranslated);
        if (allDone) {
          finalJob.status = 'completed';
          finalJob.completedChapters = finalJob.totalChapters;
          finalJob.currentProgressPercent = 100;
          finalJob.updatedAt = Date.now();
          this.syncNovelToStorage(finalJob);
          this.persistJobs();

          try {
            window.dispatchEvent(
              new CustomEvent('novelTranslationCompleted', {
                detail: {
                  novelId: finalJob.novelId,
                  novelTitle: finalJob.novelTitle,
                  totalChapters: finalJob.totalChapters,
                },
              })
            );
          } catch {}
        }
      }
    } catch (e: any) {
      const j = this.jobs.get(jobId);
      if (j) {
        j.status = 'error';
        j.error = e?.message || 'خطا در ترجمه پس‌زمینه';
        this.persistJobs();
      }
    } finally {
      this.activeWorkers.delete(jobId);
      this.abortControllers.delete(jobId);
    }
  }

  public async pauseJob(jobId: string) {
    const job = this.jobs.get(jobId);
    if (!job) return;

    if (job.isServerJob) {
      try {
        await fetch(`/api/translation/server-jobs/${jobId}/pause`, { method: 'POST' });
      } catch {}
    }

    job.status = 'paused';
    job.updatedAt = Date.now();
    const ctrl = this.abortControllers.get(jobId);
    if (ctrl) {
      ctrl.abort();
      this.abortControllers.delete(jobId);
    }
    this.activeWorkers.delete(jobId);
    this.persistJobs();
  }

  public async resumeJob(jobId: string) {
    const job = this.jobs.get(jobId);
    if (!job) return;

    if (job.isServerJob) {
      try {
        await fetch(`/api/translation/server-jobs/${jobId}/resume`, { method: 'POST' });
      } catch {}
    } else {
      job.status = 'running';
      job.error = undefined;
      job.updatedAt = Date.now();
      this.persistJobs();
      this.runJob(jobId);
    }
  }

  public async cancelJob(jobId: string) {
    const job = this.jobs.get(jobId);
    if (!job) return;

    if (job.isServerJob) {
      try {
        await fetch(`/api/translation/server-jobs/${jobId}`, { method: 'DELETE' });
      } catch {}
    }

    job.status = 'cancelled';
    job.updatedAt = Date.now();
    const ctrl = this.abortControllers.get(jobId);
    if (ctrl) {
      ctrl.abort();
      this.abortControllers.delete(jobId);
    }
    this.activeWorkers.delete(jobId);
    this.persistJobs();
  }

  public async removeJob(jobId: string) {
    await this.cancelJob(jobId);
    this.jobs.delete(jobId);
    this.persistJobs();
  }
}

export const backgroundNovelTranslator = new BackgroundNovelTranslationManager();
